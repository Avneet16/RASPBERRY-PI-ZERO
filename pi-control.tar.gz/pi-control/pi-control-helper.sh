#!/bin/bash
# pi-control-helper.sh - restricted actions runnable via sudo NOPASSWD.
# Only THIS script is granted NOPASSWD sudo (see sudoers snippet) - not a
# wildcard on systemctl/nmcli/etc. Every action is whitelisted here.
set -euo pipefail

ALLOWED_SERVICES="AdGuardHome unbound vaultwarden tailscaled nginx ufw fail2ban"

case "${1:-}" in
  restart)
    svc="${2:-}"
    for s in $ALLOWED_SERVICES; do
      if [ "$s" = "$svc" ]; then
        systemctl restart "$svc"
        exit 0
      fi
    done
    echo "service not allowed: $svc" >&2
    exit 1
    ;;
  clean-logs)
    journalctl --vacuum-size=20M
    find /var/log -type f -name "*.gz" -delete
    find /var/log -type f -name "*.1" -delete
    exit 0
    ;;
  clean-apt)
    apt-get clean
    exit 0
    ;;
  connect-saved)
    ssid="${2:-}"
    nmcli connection up "$ssid"
    exit 0
    ;;
  connect-new)
    ssid="${2:-}"
    # Password arrives over stdin, not argv - keeps it out of `ps`/`/proc`.
    read -r password
    nmcli device wifi connect "$ssid" password "$password"
    exit 0
    ;;
  unbound-stats)
    unbound-control stats_noreset
    exit 0
    ;;
  ufw-status)
    ufw status | head -1
    exit 0
    ;;
  proton-list)
    ls /etc/wireguard/proton-*.conf 2>/dev/null | xargs -n1 basename | sed 's/\.conf$//;s/^proton-//' || true
    exit 0
    ;;
  proton-status)
    active=$(ip -o link show type wireguard 2>/dev/null | awk -F': ' '{print $2}' | grep '^proton-' | head -1 || true)
    if [ -z "$active" ]; then
      echo "not_configured"
    else
      echo "ACTIVE:$active"
      wg show "$active" dump
    fi
    exit 0
    ;;
  proton-switch)
    target="proton-${2:-}"
    current=$(ip -o link show type wireguard 2>/dev/null | awk -F': ' '{print $2}' | grep '^proton-' | head -1 | tr -d '[:space:]' || true)
    if [ -n "$current" ] && [ "$current" != "$target" ]; then
      wg-quick down "$current" || true
    fi
    if [ "$current" != "$target" ]; then
      wg-quick up "$target"
    else
      echo "already active: $target"
    fi
    exit 0
    ;;
  proton-off)
    current=$(ip -o link show type wireguard 2>/dev/null | awk -F': ' '{print $2}' | grep '^proton-' | head -1 | tr -d '[:space:]' || true)
    if [ -n "$current" ]; then
      wg-quick down "$current"
    else
      echo "already down"
    fi
    exit 0
    ;;
  tailscale-status)
    tailscale status --json
    exit 0
    ;;
  throttled)
    vcgencmd get_throttled
    exit 0
    ;;
  telegram-test)
    # Fixed, non-user-supplied message only - this action never accepts
    # arbitrary text, so it can't be used as a message-sending oracle.
    /usr/local/bin/telegram-send.sh "Pi Control: test alert $(date '+%H:%M:%S') - if you see this, Telegram alerting is working"
    exit 0
    ;;
  system-events)
    {
      journalctl -k --since "-24 hours" \
        -g "Out of memory|Killed process|Under-voltage detected|Voltage normalised" \
        --no-pager -o short-iso 2>/dev/null
      journalctl -t network-failover --since "-24 hours" --no-pager -o short-iso 2>/dev/null
    } | sort || true
    exit 0
    ;;
  zram-stats)
    zramctl --output NAME,DISKSIZE,DATA,COMPR --bytes --noheadings 2>/dev/null || true
    exit 0
    ;;
  fail2ban-banned)
    jails=$(fail2ban-client status 2>/dev/null | awk -F':' '/Jail list/{print $2}' | tr ',' ' ' || true)
    for jail in $jails; do
      banned=$(fail2ban-client status "$jail" 2>/dev/null | awk -F':' '/Banned IP list/{print $2}' || true)
      for ip in $banned; do
        echo "${jail}:${ip}"
      done
    done
    exit 0
    ;;
  fail2ban-unban)
    jail="${2:-}"
    ip="${3:-}"
    fail2ban-client set "$jail" unbanip "$ip"
    exit 0
    ;;
  validate-config)
    svc="${2:-}"
    case "$svc" in
      AdGuardHome)
        python3 -c "import yaml; yaml.safe_load(open('/opt/AdGuardHome/AdGuardHome.yaml'))"
        ;;
      unbound)
        unbound-checkconf
        ;;
      *)
        echo "no validator for service: $svc" >&2
        exit 1
        ;;
    esac
    exit 0
    ;;
  reboot)
    systemctl reboot
    exit 0
    ;;
  egress-exit)
    curl -s --max-time 5 --interface tailscale0 https://ifconfig.me
    exit 0
    ;;
  apt-check)
    apt-get update -qq
    apt list --upgradable 2>/dev/null | grep -c upgradable || true
    exit 0
    ;;
  full-upgrade)
    apt-get update -qq
    DEBIAN_FRONTEND=noninteractive apt-get -y \
      -o Dpkg::Options::="--force-confdef" \
      -o Dpkg::Options::="--force-confold" \
      full-upgrade
    apt-get -y autoremove
    exit 0
    ;;
  *)
    echo "unknown action" >&2
    exit 1
    ;;
esac
