#!/bin/bash
# pi-control-helper.sh - restricted actions runnable via sudo NOPASSWD.
# Only THIS script is granted NOPASSWD sudo (see sudoers snippet) - not a
# wildcard on systemctl/nmcli/etc. Every action is whitelisted here.
set -euo pipefail

ALLOWED_SERVICES="AdGuardHome unbound vaultwarden tailscaled nginx ufw fail2ban"

# Static-site nginx configs this dashboard is allowed to enable/disable -
# NOT arbitrary, $site comes in from an API call so it must match one of
# these exact basenames under sites-available/ or nothing happens. Keep in
# sync with NGINX_SITES in app.py.
ALLOWED_NGINX_SITES="bentopdf omni-tools"

case "${1:-}" in
  restart)
    svc="${2:-}"
    for s in $ALLOWED_SERVICES; do
      if [ "$s" = "$svc" ]; then
        systemctl restart "$svc"
        exit 0
      fi
    done
    echo "service not allowed: $svc" >&2
    exit 1
    ;;
  site-status)
    site="${2:-}"
    for s in $ALLOWED_NGINX_SITES; do
      if [ "$s" = "$site" ]; then
        if [ -L "/etc/nginx/sites-enabled/$site" ]; then
          echo "enabled"
        else
          echo "disabled"
        fi
        exit 0
      fi
    done
    echo "site not allowed: $site" >&2
    exit 1
    ;;
  site-enable)
    site="${2:-}"
    for s in $ALLOWED_NGINX_SITES; do
      if [ "$s" = "$site" ]; then
        ln -sf "/etc/nginx/sites-available/$site" "/etc/nginx/sites-enabled/$site"
        nginx -t && systemctl reload nginx
        exit 0
      fi
    done
    echo "site not allowed: $site" >&2
    exit 1
    ;;
  site-disable)
    site="${2:-}"
    for s in $ALLOWED_NGINX_SITES; do
      if [ "$s" = "$site" ]; then
        rm -f "/etc/nginx/sites-enabled/$site"
        nginx -t && systemctl reload nginx
        exit 0
      fi
    done
    echo "site not allowed: $site" >&2
    exit 1
    ;;
  clean-logs)
    # Time-based retention instead of a hard 20M size cap / unconditional
    # delete-everything-rotated - this Pi has 26GB free, there's no real
    # pressure to keep the journal that small, and wiping every rotated log
    # regardless of age destroys anything useful for investigating an
    # incident from more than a few hours back.
    journalctl --vacuum-time=7d
    find /var/log -type f -name "*.gz" -mtime +30 -delete
    find /var/log -type f -name "*.1" -mtime +30 -delete
    exit 0
    ;;
  clean-apt)
    apt-get clean
    exit 0
    ;;
  connect-saved)
    ssid="${2:-}"
    nmcli connection up "$ssid"
    exit 0
    ;;
  connect-new)
    ssid="${2:-}"
    # Password arrives over stdin, not argv - keeps it out of `ps`/`/proc`.
    read -r password
    nmcli device wifi connect "$ssid" password "$password"
    exit 0
    ;;
  unbound-stats)
    unbound-control stats_noreset
    exit 0
    ;;
  ufw-status)
    ufw status | head -1
    exit 0
    ;;
  proton-list)
    ls /etc/wireguard/proton-*.conf 2>/dev/null | xargs -n1 basename | sed 's/\.conf$//;s/^proton-//' || true
    exit 0
    ;;
  proton-status)
    active=$(ip -o link show type wireguard 2>/dev/null | awk -F': ' '{print $2}' | grep '^proton-' | head -1 || true)
    if [ -z "$active" ]; then
      echo "not_configured"
    else
      echo "ACTIVE:$active"
      wg show "$active" dump
    fi
    exit 0
    ;;
  proton-switch)
    target="proton-${2:-}"
    current=$(ip -o link show type wireguard 2>/dev/null | awk -F': ' '{print $2}' | grep '^proton-' | head -1 | tr -d '[:space:]' || true)
    if [ -n "$current" ] && [ "$current" != "$target" ]; then
      wg-quick down "$current" || true
    fi
    if [ "$current" != "$target" ]; then
      wg-quick up "$target"
    else
      echo "already active: $target"
    fi
    exit 0
    ;;
  proton-off)
    current=$(ip -o link show type wireguard 2>/dev/null | awk -F': ' '{print $2}' | grep '^proton-' | head -1 | tr -d '[:space:]' || true)
    if [ -n "$current" ]; then
      wg-quick down "$current"
    else
      echo "already down"
    fi
    exit 0
    ;;
  tailscale-status)
    tailscale status --json
    exit 0
    ;;
  throttled)
    vcgencmd get_throttled
    exit 0
    ;;
  telegram-test)
    # Fixed, non-user-supplied message only - this action never accepts
    # arbitrary text, so it can't be used as a message-sending oracle.
    /usr/local/bin/telegram-send.sh "Pi Control: test alert $(date '+%H:%M:%S') - if you see this, Telegram alerting is working"
    exit 0
    ;;
  telegram-alert)
    # Server-generated status text only - called from the dashboard's own
    # background threads, never wired to an HTTP route, so this isn't
    # reachable with arbitrary user input the way an API action would be.
    msg="${2:-}"
    /usr/local/bin/telegram-send.sh "$msg"
    exit 0
    ;;
  system-events)
    # SD cards don't expose SMART data, so mmcblk/Buffer-I/O/EXT4-fs kernel
    # log lines are the only portable, no-extra-dependency way to catch
    # early card degradation - a read-only remount in particular is the
    # classic failing-SD-card symptom.
    #
    # journalctl prints a literal "-- No entries --" line when a query
    # matches nothing (on some systemd versions) - filtered out below so
    # it never gets treated as a real event by the caller.
    {
      journalctl -k --since "-24 hours" \
        -g "Out of memory|Killed process|Under-voltage detected|Voltage normalised|mmcblk.*error|Buffer I/O error|EXT4-fs error|EXT4-fs.*read-only" \
        --no-pager -o short-iso 2>/dev/null
      journalctl -t network-failover --since "-24 hours" --no-pager -o short-iso 2>/dev/null
    } | grep -v -- '^-- No entries --$' | sort || true
    exit 0
    ;;
  zram-stats)
    zramctl --output NAME,DISKSIZE,DATA,COMPR --bytes --noheadings 2>/dev/null || true
    exit 0
    ;;
  fail2ban-banned)
    jails=$(fail2ban-client status 2>/dev/null | awk -F':' '/Jail list/{print $2}' | tr ',' ' ' || true)
    for jail in $jails; do
      banned=$(fail2ban-client status "$jail" 2>/dev/null | awk -F':' '/Banned IP list/{print $2}' || true)
      for ip in $banned; do
        echo "${jail}:${ip}"
      done
    done
    exit 0
    ;;
  fail2ban-unban)
    jail="${2:-}"
    ip="${3:-}"
    fail2ban-client set "$jail" unbanip "$ip"
    exit 0
    ;;
  validate-config)
    svc="${2:-}"
    case "$svc" in
      AdGuardHome)
        python3 -c "import yaml; yaml.safe_load(open('/opt/AdGuardHome/AdGuardHome.yaml'))"
        ;;
      unbound)
        unbound-checkconf
        ;;
      *)
        echo "no validator for service: $svc" >&2
        exit 1
        ;;
    esac
    exit 0
    ;;
  reboot)
    systemctl reboot
    exit 0
    ;;
  egress-exit)
    # `--interface tailscale0` restricts the WHOLE request to that device via
    # SO_BINDTODEVICE, including curl's own DNS lookup - but that lookup goes
    # to 127.0.0.1:53 (AdGuard), which isn't reachable when the socket is
    # bound to tailscale0 instead of lo, so the request failed before it ever
    # got to the HTTPS part. Fix: resolve via the normal unrestricted
    # resolver first, then hand curl the IP directly with --resolve so it
    # never needs to do its own DNS lookup over the bound interface.
    # `timeout 5` bounds the getent step - it has no built-in timeout of its
    # own, and a slow/unreachable resolver here could otherwise push the
    # whole helper past the caller's outer subprocess timeout before curl's
    # own --max-time ever gets a chance to fire and echo a diagnostic.
    ip=$(timeout 5 getent ahostsv4 ifconfig.me 2>/dev/null | head -1 | awk '{print $1}' || true)
    if [ -z "$ip" ]; then
      echo "dns_resolve_failed"
      exit 0
    fi
    curl -4 -s -S --max-time 8 --interface tailscale0 --resolve "ifconfig.me:443:$ip" https://ifconfig.me 2>&1 \
      || echo "curl_failed_via_tailscale0"
    exit 0
    ;;
  apt-check)
    apt-get update -qq
    apt list --upgradable 2>/dev/null | grep -c upgradable || true
    exit 0
    ;;
  normal-upgrade)
    # Plain `apt upgrade` - never removes an installed package or pulls in
    # a new one to satisfy a dependency change, unlike full-upgrade below.
    # No autoremove either, for the same conservative reasoning.
    apt-get update -qq
    DEBIAN_FRONTEND=noninteractive apt-get -y \
      -o Dpkg::Options::="--force-confdef" \
      -o Dpkg::Options::="--force-confold" \
      upgrade
    exit 0
    ;;
  full-upgrade)
    apt-get update -qq
    DEBIAN_FRONTEND=noninteractive apt-get -y \
      -o Dpkg::Options::="--force-confdef" \
      -o Dpkg::Options::="--force-confold" \
      full-upgrade
    apt-get -y autoremove
    exit 0
    ;;
  service-logs)
    # Confirmed 2026-07-29 by direct inspection of the real Pi (see Runbook):
    #   AdGuardHome - unit sets StandardOutput/Error=journal explicitly and
    #     there's no separate log file under /opt/AdGuardHome - an empty
    #     journal here means genuinely nothing logged recently, not a
    #     wrong-path problem
    #   unbound     - no logfile:/use-syslog: configured in
    #     /etc/unbound/unbound.conf.d/*.conf, so at default verbosity it
    #     only logs startup/errors - quiet, error-free operation is
    #     expected to produce nothing. Also runs via a chroot helper,
    #     which can silently block syslog delivery if that's ever
    #     configured later (checked via -t as a fallback regardless)
    #   nginx       - real logs in /var/log/nginx/{error,access}.log -
    #     error.log is very often 0 bytes when nginx is healthy, so
    #     access.log is tried too rather than reporting "empty"
    #   ufw         - its own unit is just the oneshot rule loader by
    #     design (never has ongoing output) - actual firewall block/allow
    #     activity, if `ufw logging on` is enabled, lands in the kernel
    #     log instead
    #   fail2ban    - real log in /var/log/fail2ban.log (logtarget
    #     setting in /etc/fail2ban/fail2ban.conf)
    unit="${2:-}"
    lines="${3:-100}"
    case "$unit" in
      AdGuardHome|unbound|vaultwarden|tailscaled|nginx|ufw|fail2ban|picontrol) ;;
      *)
        echo "unit not allowed: $unit" >&2
        exit 1
        ;;
    esac

    out=$(journalctl -u "$unit" -n "$lines" --no-pager -o short-iso 2>/dev/null | grep -v -- '^-- No entries --$' || true)

    if [ -z "$out" ] && [ "$unit" = "unbound" ]; then
      out=$(journalctl -t unbound -n "$lines" --no-pager -o short-iso 2>/dev/null | grep -v -- '^-- No entries --$' || true)
    fi

    if [ -z "$out" ] && [ "$unit" = "ufw" ]; then
      out=$(journalctl -k -g '\[UFW' --since "-24 hours" -n "$lines" --no-pager -o short-iso 2>/dev/null \
        | grep -v -- '^-- No entries --$' || true)
    fi

    if [ -z "$out" ]; then
      logfiles=""
      case "$unit" in
        nginx) logfiles="/var/log/nginx/error.log /var/log/nginx/access.log" ;;
        fail2ban) logfiles="/var/log/fail2ban.log" ;;
      esac
      for logfile in $logfiles; do
        if [ -r "$logfile" ]; then
          content=$(tail -n "$lines" "$logfile" 2>/dev/null || true)
          if [ -n "$content" ]; then
            out="[journalctl had nothing - showing $logfile instead]"$'\n'"$content"
            break
          fi
        fi
      done
    fi

    if [ -z "$out" ]; then
      case "$unit" in
        AdGuardHome)
          out="Nothing in the journal for AdGuardHome (it logs via journal only - no separate log file exists). Likely just quiet operation, not an error."
          ;;
        unbound)
          out="Nothing found for unbound. No logfile:/use-syslog: is configured, so at default verbosity it only logs startup/errors - quiet, error-free operation legitimately produces nothing here. Add logfile: \"/var/log/unbound/unbound.log\" to unbound.conf if you want ongoing output."
          ;;
        ufw)
          out="ufw.service is just the oneshot rule loader (nothing ongoing to log there by design), and no firewall block/allow activity was found in the kernel log either. Run 'sudo ufw logging on' if you want that visibility."
          ;;
        *)
          out="No log output found for $unit via journalctl or its known log file. It may log somewhere else, or simply hasn't emitted anything in its retained history."
          ;;
      esac
    fi
    echo "$out"
    exit 0
    ;;
  ufw-rules)
    ufw status verbose 2>/dev/null || true
    exit 0
    ;;
  fail2ban-summary)
    jails=$(fail2ban-client status 2>/dev/null | awk -F':' '/Jail list/{print $2}' | tr ',' ' ' || true)
    for jail in $jails; do
      status=$(fail2ban-client status "$jail" 2>/dev/null || true)
      total_failed=$(echo "$status" | awk -F':' '/Total failed/{gsub(/ /,"",$2); print $2}')
      total_banned=$(echo "$status" | awk -F':' '/Total banned/{gsub(/ /,"",$2); print $2}')
      currently_failed=$(echo "$status" | awk -F':' '/Currently failed/{gsub(/ /,"",$2); print $2}')
      currently_banned=$(echo "$status" | awk -F':' '/Currently banned/{gsub(/ /,"",$2); print $2}')
      echo "${jail}|${total_failed:-0}|${total_banned:-0}|${currently_failed:-0}|${currently_banned:-0}"
    done
    exit 0
    ;;
  ssh-auth-log)
    journalctl -u ssh --since "-24 hours" -g "Accepted|Failed password|Invalid user" \
      --no-pager -o short-iso 2>/dev/null | grep -v -- '^-- No entries --$' | tail -50 || true
    exit 0
    ;;
  *)
    echo "unknown action" >&2
    exit 1
    ;;
esac
