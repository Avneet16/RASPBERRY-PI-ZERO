#!/bin/bash
# pi-control-helper.sh - restricted actions runnable via sudo NOPASSWD.
# Only THIS script is granted NOPASSWD sudo (see sudoers snippet) - not a
# wildcard on systemctl/nmcli/etc. Every action is whitelisted here.
set -euo pipefail

ALLOWED_SERVICES="AdGuardHome unbound vaultwarden tailscaled nginx ufw fail2ban"

case "${1:-}" in
  restart)
    svc="${2:-}"
    for s in $ALLOWED_SERVICES; do
      if [ "$s" = "$svc" ]; then
        systemctl restart "$svc"
        exit 0
      fi
    done
    echo "service not allowed: $svc" >&2
    exit 1
    ;;
  clean-logs)
    journalctl --vacuum-size=20M
    find /var/log -type f -name "*.gz" -delete
    find /var/log -type f -name "*.1" -delete
    exit 0
    ;;
  clean-apt)
    apt-get clean
    exit 0
    ;;
  connect-saved)
    ssid="${2:-}"
    nmcli connection up "$ssid"
    exit 0
    ;;
  connect-new)
    ssid="${2:-}"
    # Password arrives over stdin, not argv - keeps it out of `ps`/`/proc`.
    read -r password
    nmcli device wifi connect "$ssid" password "$password"
    exit 0
    ;;
  unbound-stats)
    unbound-control stats_noreset
    exit 0
    ;;
  ufw-status)
    ufw status | head -1
    exit 0
    ;;
  proton-list)
    ls /etc/wireguard/proton-*.conf 2>/dev/null | xargs -n1 basename | sed 's/\.conf$//;s/^proton-//' || true
    exit 0
    ;;
  proton-status)
    active=$(ip -o link show type wireguard 2>/dev/null | awk -F': ' '{print $2}' | grep '^proton-' | head -1 || true)
    if [ -z "$active" ]; then
      echo "not_configured"
    else
      echo "ACTIVE:$active"
      wg show "$active" dump
    fi
    exit 0
    ;;
  proton-switch)
    target="proton-${2:-}"
    current=$(ip -o link show type wireguard 2>/dev/null | awk -F': ' '{print $2}' | grep '^proton-' | head -1 | tr -d '[:space:]' || true)
    if [ -n "$current" ] && [ "$current" != "$target" ]; then
      wg-quick down "$current" || true
    fi
    if [ "$current" != "$target" ]; then
      wg-quick up "$target"
    else
      echo "already active: $target"
    fi
    exit 0
    ;;
  proton-off)
    current=$(ip -o link show type wireguard 2>/dev/null | awk -F': ' '{print $2}' | grep '^proton-' | head -1 | tr -d '[:space:]' || true)
    if [ -n "$current" ]; then
      wg-quick down "$current"
    else
      echo "already down"
    fi
    exit 0
    ;;
  tailscale-status)
    tailscale status --json
    exit 0
    ;;
  throttled)
    vcgencmd get_throttled
    exit 0
    ;;
  oom-events)
    journalctl -k --since "-24 hours" -g "Out of memory|Killed process" --no-pager -o short-iso 2>/dev/null || true
    exit 0
    ;;
  reboot)
    systemctl reboot
    exit 0
    ;;
  egress-exit)
    curl -s --max-time 5 --interface tailscale0 https://ifconfig.me
    exit 0
    ;;
  apt-check)
    apt-get update -qq
    apt list --upgradable 2>/dev/null | grep -c upgradable || true
    exit 0
    ;;
  full-upgrade)
    apt-get update -qq
    DEBIAN_FRONTEND=noninteractive apt-get -y \
      -o Dpkg::Options::="--force-confdef" \
      -o Dpkg::Options::="--force-confold" \
      full-upgrade
    apt-get -y autoremove
    exit 0
    ;;
  *)
    echo "unknown action" >&2
    exit 1
    ;;
esac
