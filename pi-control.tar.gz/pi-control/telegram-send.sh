#!/bin/bash
# telegram-send.sh - sends a message via the Telegram bot API.
# Deploys to /usr/local/bin/telegram-send.sh (needs chmod +x after copying -
# root-owned since it reads /etc/pi-control-secrets, invoked as root via
# pi-control-helper.sh's `telegram-test` action, or directly by anything
# else running as root, e.g. network-failover.sh).
source /etc/pi-control-secrets
MSG="$1"

# Plain `curl -s` alone only fails on transport-level problems (DNS,
# connection refused) - a bad token or chat ID still comes back as a
# normal HTTP 200 with "ok":false in the body, so the old version of this
# script always reported success even when nothing was actually sent.
RESPONSE=$(curl -s -X POST "https://api.telegram.org/bot$TG_TOKEN/sendMessage" \
  -d chat_id="$TG_CHAT" \
  -d text="$MSG")

if echo "$RESPONSE" | grep -q '"ok":true'; then
  exit 0
else
  echo "telegram-send failed: $RESPONSE" >&2
  exit 1
fi
