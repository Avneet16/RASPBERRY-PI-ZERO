"""Pi Control - lightweight system dashboard for the Pi."""
import json
import secrets
import subprocess
import time
import threading
from collections import deque

from flask import Flask, jsonify, render_template, request
import psutil

app = Flask(__name__)

HELPER = "/usr/local/bin/pi-control-helper.sh"

# Synchronizer-token CSRF guard for the state-changing /api/ POST routes.
# Regenerated on every process start; embedded in index.html and echoed back
# by the frontend as the X-CSRF-Token header on every POST.
CSRF_TOKEN = secrets.token_hex(32)


@app.before_request
def _check_csrf():
    if request.method == "POST" and request.path.startswith("/api/"):
        if request.headers.get("X-CSRF-Token") != CSRF_TOKEN:
            return jsonify({"ok": False, "error": "invalid csrf token"}), 403

SERVICES = [
    ("AdGuardHome", "AdGuard"),
    ("unbound", "Unbound"),
    ("vaultwarden", "Vaultwarden"),
    ("tailscaled", "Tailscale"),
    ("nginx", "Nginx"),
    ("ufw", "UFW"),
    ("fail2ban", "Fail2Ban"),
]

# Rolling in-memory history for the performance trends chart (~1hr at 60s samples)
HISTORY = deque(maxlen=60)


def _cpu_temp():
    try:
        with open("/sys/class/thermal/thermal_zone0/temp") as f:
            return round(int(f.read().strip()) / 1000, 1)
    except Exception:
        return None


def _sample_loop():
    while True:
        try:
            HISTORY.append({
                "t": time.strftime("%H:%M"),
                "temp": _cpu_temp(),
                "cpu": psutil.cpu_percent(interval=None),
                "ram": psutil.virtual_memory().percent,
            })
        except Exception:
            pass
        time.sleep(60)


threading.Thread(target=_sample_loop, daemon=True).start()


# Shared cache, populated by background threads so requests never block on
# subprocess spawns - the API just serves whatever was last computed.
CACHE_LOCK = threading.Lock()
CACHE = {
    "live": {"cpu_load": 0, "temp": None, "ram_pct": 0, "ram_used_mb": 0,
              "ram_total_mb": 0, "avg_load": [0, 0, 0]},
    "services": [],
    "unbound": {"hit_rate": None, "hits": None, "misses": None},
    "cores": [],
    "top_procs": [],
    "top_mem_procs": [],
    "net_ifaces": [],
    "proton": {"up": False, "handshake_age_s": None, "rx_mb": None, "tx_mb": None},
    "net": {"mode": "unknown", "saved_networks": [], "available_networks": [],
             "ts_self_offers_exit": False, "ts_peers": []},
    "disk": {"arrays": [], "reclaim": []},
    "power": {"undervoltage_now": False, "freq_capped_now": False, "throttled_now": False,
               "undervoltage_occurred": False, "freq_capped_occurred": False, "throttled_occurred": False},
    "oom_events": [],
}


def _service_statuses():
    """One batched systemctl call for all units, instead of one call each."""
    units = [u for u, _ in SERVICES]
    blocks = []
    try:
        out = subprocess.run(
            ["systemctl", "show", *units, "--property=ActiveState,MainPID,MemoryCurrent"],
            capture_output=True, text=True, timeout=5,
        ).stdout
        blocks = out.strip().split("\n\n")
    except Exception:
        pass

    ufw_active = False
    try:
        ufw_out = subprocess.run(["sudo", HELPER, "ufw-status"], capture_output=True, text=True, timeout=5).stdout
        ufw_active = "Status: active" in ufw_out
    except Exception:
        pass

    results = []
    for i, (unit, label) in enumerate(SERVICES):
        props = {}
        if i < len(blocks):
            props = dict(line.split("=", 1) for line in blocks[i].strip().splitlines() if "=" in line)

        # UFW's unit is a one-shot script that exits after applying rules -
        # ActiveState goes back to "inactive" even though the firewall is
        # still live, so it needs its own real status check.
        active = ufw_active if unit == "ufw" else props.get("ActiveState") == "active"

        mem = props.get("MemoryCurrent", "0")
        if mem.isdigit() and int(mem) > 0:
            mem_mb = round(int(mem) / (1024 * 1024), 1)
        else:
            # MemoryCurrent is often unset unless cgroup accounting is
            # explicitly enabled - fall back to reading the process directly.
            mem_mb = 0
            pid = props.get("MainPID", "0")
            if pid.isdigit() and int(pid) > 0:
                try:
                    mem_mb = round(psutil.Process(int(pid)).memory_info().rss / (1024 * 1024), 1)
                except Exception:
                    mem_mb = 0

        results.append({"unit": unit, "label": label, "active": active, "mem_mb": mem_mb})
    return results


NET_INTERFACES = ["eth0", "wlan0", "tailscale0", "proton"]


def _net_iface_stats():
    counters = psutil.net_io_counters(pernic=True)
    result = []
    for name in NET_INTERFACES:
        c = counters.get(name)
        result.append({
            "iface": name,
            "rx_mb": round(c.bytes_recv / (1024 * 1024), 1) if c else None,
            "tx_mb": round(c.bytes_sent / (1024 * 1024), 1) if c else None,
        })
    return result


def _proton_status():
    try:
        out = subprocess.run(["sudo", HELPER, "proton-status"], capture_output=True, text=True, timeout=5).stdout
    except Exception:
        out = ""
    out = out.strip()
    if not out or out == "not_configured":
        return {"up": False, "active_server": None, "handshake_age_s": None, "rx_mb": None, "tx_mb": None}

    lines = out.splitlines()
    if not lines or not lines[0].startswith("ACTIVE:"):
        return {"up": False, "active_server": None, "handshake_age_s": None, "rx_mb": None, "tx_mb": None}

    active_server = lines[0].split(":", 1)[1].replace("proton-", "", 1)

    if len(lines) < 3:
        return {"up": True, "active_server": active_server, "handshake_age_s": None, "rx_mb": None, "tx_mb": None}

    # lines[1] is wg's own interface line, lines[2] is the first peer
    peer = lines[2].split("\t")
    if len(peer) < 7:
        return {"up": True, "active_server": active_server, "handshake_age_s": None, "rx_mb": None, "tx_mb": None}

    latest_handshake = int(peer[4]) if peer[4].isdigit() else 0
    rx = int(peer[5]) if peer[5].isdigit() else 0
    tx = int(peer[6]) if peer[6].isdigit() else 0
    age = round(time.time() - latest_handshake) if latest_handshake > 0 else None

    return {
        "up": True,
        "active_server": active_server,
        "handshake_age_s": age,
        "rx_mb": round(rx / (1024 * 1024), 1),
        "tx_mb": round(tx / (1024 * 1024), 1),
    }


# vcgencmd get_throttled bit layout: bits 0-3 are the current state, bits
# 16-19 are "has this happened at least once since boot" - see
# https://www.raspberrypi.com/documentation/computers/os.html#get_throttled
def _power_status():
    default = {"undervoltage_now": False, "freq_capped_now": False, "throttled_now": False,
               "undervoltage_occurred": False, "freq_capped_occurred": False, "throttled_occurred": False}
    try:
        out = subprocess.run(["sudo", HELPER, "throttled"], capture_output=True, text=True, timeout=5).stdout.strip()
        value = int(out.split("=", 1)[1], 16)
    except Exception:
        return default
    return {
        "undervoltage_now": bool(value & (1 << 0)),
        "freq_capped_now": bool(value & (1 << 1)),
        "throttled_now": bool(value & (1 << 2)),
        "undervoltage_occurred": bool(value & (1 << 16)),
        "freq_capped_occurred": bool(value & (1 << 17)),
        "throttled_occurred": bool(value & (1 << 18)),
    }


def _sample_fast():
    """Every ~3s: cheap system stats + service status, all served from cache."""
    while True:
        try:
            load1, load5, load15 = psutil.getloadavg()
            vm = psutil.virtual_memory()
            sw = psutil.swap_memory()
            with CACHE_LOCK:
                CACHE["live"] = {
                    "cpu_load": psutil.cpu_percent(interval=None),
                    "temp": _cpu_temp(),
                    "ram_pct": vm.percent,
                    "ram_used_mb": round(vm.used / (1024 * 1024)),
                    "ram_total_mb": round(vm.total / (1024 * 1024)),
                    "avg_load": [round(load1, 2), round(load5, 2), round(load15, 2)],
                    "swap_pct": sw.percent,
                    "swap_used_mb": round(sw.used / (1024 * 1024)),
                    "swap_total_mb": round(sw.total / (1024 * 1024)),
                }
                CACHE["cores"] = psutil.cpu_percent(percpu=True, interval=None)
                CACHE["services"] = _service_statuses()
                CACHE["net_ifaces"] = _net_iface_stats()
                CACHE["proton"] = _proton_status()
                CACHE["power"] = _power_status()
        except Exception:
            pass
        time.sleep(3)


def _oom_events():
    """Kernel OOM-killer lines from the last 24h - cheap, not time-critical."""
    try:
        out = subprocess.run(["sudo", HELPER, "oom-events"], capture_output=True, text=True, timeout=10).stdout
    except Exception:
        return []
    return [line.strip() for line in out.splitlines() if line.strip()][-10:]


def _sample_slow():
    """Every ~15s: unbound stats (needs sudo, slower) + top memory-using processes."""
    while True:
        unbound = {"hit_rate": None, "hits": None, "misses": None}
        try:
            out = subprocess.run(["sudo", HELPER, "unbound-stats"], capture_output=True, text=True, timeout=5).stdout
            stats = dict(line.split("=", 1) for line in out.splitlines() if "=" in line)
            hits = int(stats.get("total.num.cachehits", 0))
            misses = int(stats.get("total.num.cachemiss", 0))
            total = hits + misses
            unbound = {
                "hit_rate": round(100 * hits / total, 1) if total else 0,
                "hits": hits,
                "misses": misses,
            }
        except Exception:
            pass

        cpu_procs, mem_procs = [], []
        for p in psutil.process_iter(["name", "cpu_percent", "memory_info"]):
            try:
                mem_mb = round(p.info["memory_info"].rss / (1024 * 1024), 1) if p.info["memory_info"] else 0
                cpu_procs.append((p.info["name"], p.info["cpu_percent"]))
                mem_procs.append((p.info["name"], mem_mb))
            except Exception:
                continue
        top_cpu = sorted(cpu_procs, key=lambda x: x[1] or 0, reverse=True)[:5]
        top_mem = sorted(mem_procs, key=lambda x: x[1] or 0, reverse=True)[:5]

        with CACHE_LOCK:
            CACHE["unbound"] = unbound
            CACHE["top_procs"] = [{"name": n, "cpu_pct": c} for n, c in top_cpu if n]
            CACHE["top_mem_procs"] = [{"name": n, "mem_mb": m} for n, m in top_mem if n]
            CACHE["oom_events"] = _oom_events()
        time.sleep(15)


def _sample_net():
    """Every ~8s: nmcli (can be slow, especially a wifi scan) + tailscale status."""
    while True:
        try:
            status = _nmcli("-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device", "status")
            mode = "unknown"
            for line in status.splitlines():
                parts = line.split(":")
                if len(parts) >= 4 and parts[0] == "eth0" and parts[2] == "connected":
                    mode = "ethernet"
                elif len(parts) >= 4 and parts[0] == "wlan0" and parts[2] == "connected":
                    mode = "ap (failover)" if parts[3] == "wlan0-ap" else "wifi-client"

            saved = []
            for line in _nmcli("-t", "-f", "NAME,TYPE", "connection", "show").splitlines():
                parts = line.split(":")
                if len(parts) >= 2 and parts[1] == "802-11-wireless" and parts[0] != "wlan0-ap":
                    saved.append(parts[0])

            available = []
            for line in _nmcli("-t", "-f", "SSID,SECURITY,SIGNAL", "device", "wifi", "list").splitlines():
                parts = line.split(":")
                if len(parts) >= 3 and parts[0]:
                    available.append({"ssid": parts[0], "security": parts[1] or "Open", "signal": parts[2]})

            self_offers_exit = False
            peers = []
            try:
                out = subprocess.run(["sudo", HELPER, "tailscale-status"], capture_output=True, text=True, timeout=10).stdout
                data = json.loads(out)
                self_info = data.get("Self", {}) or {}
                self_offers_exit = bool(self_info.get("ExitNodeOption", False))
                peers_raw = data.get("Peer", {}) or {}
                for _, p in peers_raw.items():
                    peers.append({
                        "hostname": p.get("HostName", "unknown"),
                        "online": bool(p.get("Online", False)),
                    })
                peers.sort(key=lambda x: (not x["online"], x["hostname"]))
            except Exception:
                pass

            with CACHE_LOCK:
                CACHE["net"] = {
                    "mode": mode,
                    "saved_networks": saved,
                    "available_networks": available,
                    "ts_self_offers_exit": self_offers_exit,
                    "ts_peers": peers,
                }
        except Exception:
            pass
        time.sleep(8)


def _sample_disk():
    """Every ~30s: disk usage + reclaimable space (du walks a directory, not cheap)."""
    while True:
        arrays = []
        for mount in ["/", "/boot/firmware"]:
            try:
                u = psutil.disk_usage(mount)
                arrays.append({
                    "path": mount,
                    "used_gb": round(u.used / (1024 ** 3), 1),
                    "total_gb": round(u.total / (1024 ** 3), 1),
                    "pct": u.percent,
                })
            except Exception:
                continue

        reclaim = []
        for name, path in [("System Logs", "/var/log"), ("APT Cache", "/var/cache/apt")]:
            try:
                out = subprocess.run(["du", "-sm", path], capture_output=True, text=True, timeout=15).stdout
                size_mb = int(out.split()[0]) if out.strip() else 0
            except Exception:
                size_mb = 0
            reclaim.append({"name": name, "path": path, "size_mb": size_mb})

        with CACHE_LOCK:
            CACHE["disk"] = {"arrays": arrays, "reclaim": reclaim}
        time.sleep(30)


@app.route("/")
def index():
    return render_template("index.html", csrf_token=CSRF_TOKEN)


@app.route("/api/overview")
def api_overview():
    with CACHE_LOCK:
        return jsonify({
            "live": CACHE["live"],
            "services": CACHE["services"],
            "unbound": CACHE["unbound"],
            "power": CACHE["power"],
            "oom_events": CACHE["oom_events"],
        })


@app.route("/api/action/restart/<unit>", methods=["POST"])
def api_restart(unit):
    allowed = {u for u, _ in SERVICES}
    if unit not in allowed:
        return jsonify({"ok": False, "error": "not allowed"}), 400
    result = subprocess.run(
        ["sudo", HELPER, "restart", unit], capture_output=True, text=True, timeout=15
    )
    return jsonify({"ok": result.returncode == 0, "output": result.stdout + result.stderr})


@app.route("/api/sys")
def api_sys():
    uptime_s = time.time() - psutil.boot_time()
    days, rem = divmod(uptime_s, 86400)
    hours, rem = divmod(rem, 3600)
    minutes = rem // 60

    try:
        freq = psutil.cpu_freq().current
    except Exception:
        freq = None

    with CACHE_LOCK:
        return jsonify({
            "trends": list(HISTORY),
            "uptime": f"{int(days)}d {int(hours)}h {int(minutes)}m",
            "cpu_freq": round(freq) if freq else None,
            "cores": CACHE["cores"],
            "top_procs": CACHE["top_procs"],
            "top_mem_procs": CACHE["top_mem_procs"],
        })


# ---- system updates (background job, since full-upgrade can run long) ----
UPDATE_STATE = {"running": False, "output": "", "done_ok": None}
UPDATE_LOCK = threading.Lock()


@app.route("/api/updates/check")
def api_updates_check():
    result = subprocess.run(["sudo", HELPER, "apt-check"], capture_output=True, text=True, timeout=60)
    count_line = result.stdout.strip().splitlines()[-1] if result.stdout.strip() else "0"
    try:
        count = int(count_line)
    except ValueError:
        count = 0
    return jsonify({"ok": result.returncode == 0, "upgradable": count})


def _run_upgrade():
    with UPDATE_LOCK:
        UPDATE_STATE["running"] = True
        UPDATE_STATE["output"] = ""
        UPDATE_STATE["done_ok"] = None
    result = subprocess.run(
        ["sudo", HELPER, "full-upgrade"], capture_output=True, text=True, timeout=1800
    )
    with UPDATE_LOCK:
        UPDATE_STATE["running"] = False
        UPDATE_STATE["output"] = (result.stdout + result.stderr)[-4000:]
        UPDATE_STATE["done_ok"] = result.returncode == 0


@app.route("/api/updates/upgrade", methods=["POST"])
def api_updates_upgrade():
    with UPDATE_LOCK:
        if UPDATE_STATE["running"]:
            return jsonify({"ok": False, "error": "already running"}), 409
    threading.Thread(target=_run_upgrade, daemon=True).start()
    return jsonify({"ok": True, "started": True})


@app.route("/api/updates/status")
def api_updates_status():
    with UPDATE_LOCK:
        return jsonify(dict(UPDATE_STATE))


def _nmcli(*args):
    return subprocess.run(["nmcli", *args], capture_output=True, text=True, timeout=10).stdout


@app.route("/api/net")
def api_net():
    with CACHE_LOCK:
        net = dict(CACHE.get("net", {}))
        net["net_ifaces"] = CACHE.get("net_ifaces", [])
        net["proton"] = CACHE.get("proton", {})
    return jsonify(net)


@app.route("/api/action/wifi/connect_saved", methods=["POST"])
def api_wifi_connect_saved():
    ssid = (request.json or {}).get("ssid", "")
    result = subprocess.run(
        ["sudo", HELPER, "connect-saved", ssid], capture_output=True, text=True, timeout=20
    )
    return jsonify({"ok": result.returncode == 0, "output": result.stdout + result.stderr})


@app.route("/api/action/wifi/connect_new", methods=["POST"])
def api_wifi_connect_new():
    body = request.json or {}
    ssid = body.get("ssid", "")
    password = body.get("password", "")
    # Password goes over stdin, not argv - a CLI arg would be visible to any
    # local user via `ps`/`/proc/<pid>/cmdline` for the life of the process.
    result = subprocess.run(
        ["sudo", HELPER, "connect-new", ssid],
        input=password + "\n", capture_output=True, text=True, timeout=20,
    )
    return jsonify({"ok": result.returncode == 0, "output": result.stdout + result.stderr})


@app.route("/api/disk")
def api_disk():
    with CACHE_LOCK:
        return jsonify(dict(CACHE.get("disk", {"arrays": [], "reclaim": []})))


@app.route("/api/action/clean/<target>", methods=["POST"])
def api_clean(target):
    if target not in ("logs", "apt"):
        return jsonify({"ok": False, "error": "not allowed"}), 400
    result = subprocess.run(
        ["sudo", HELPER, f"clean-{target}"], capture_output=True, text=True, timeout=30
    )
    return jsonify({"ok": result.returncode == 0, "output": result.stdout + result.stderr})


@app.route("/api/proton/servers")
def api_proton_servers():
    try:
        out = subprocess.run(["sudo", HELPER, "proton-list"], capture_output=True, text=True, timeout=10).stdout
        servers = [s.strip() for s in out.splitlines() if s.strip()]
    except Exception:
        servers = []
    return jsonify({"servers": servers})


@app.route("/api/action/proton/switch", methods=["POST"])
def api_proton_switch():
    server = (request.json or {}).get("server", "")
    if not server or not server.replace("-", "").isalnum():
        return jsonify({"ok": False, "error": "invalid server name"}), 400
    result = subprocess.run(
        ["sudo", HELPER, "proton-switch", server], capture_output=True, text=True, timeout=20
    )
    return jsonify({"ok": result.returncode == 0, "output": result.stdout + result.stderr})


@app.route("/api/action/proton/off", methods=["POST"])
def api_proton_off():
    result = subprocess.run(["sudo", HELPER, "proton-off"], capture_output=True, text=True, timeout=20)
    return jsonify({"ok": result.returncode == 0, "output": result.stdout + result.stderr})


@app.route("/api/net/egress")
def api_net_egress():
    direct_ip = None
    try:
        direct_ip = subprocess.run(
            ["curl", "-s", "--max-time", "5", "https://ifconfig.me"],
            capture_output=True, text=True, timeout=8,
        ).stdout.strip() or None
    except Exception:
        pass

    # Binding to a specific interface (SO_BINDTODEVICE) needs CAP_NET_RAW,
    # which this unprivileged process doesn't have - route through the
    # sudo helper for this one check only.
    exit_path_ip = None
    try:
        exit_path_ip = subprocess.run(
            ["sudo", HELPER, "egress-exit"], capture_output=True, text=True, timeout=8,
        ).stdout.strip() or None
    except Exception:
        pass

    return jsonify({"direct_ip": direct_ip, "exit_path_ip": exit_path_ip})


@app.route("/api/action/reboot", methods=["POST"])
def api_reboot():
    threading.Thread(
        target=lambda: subprocess.run(["sudo", HELPER, "reboot"], capture_output=True, timeout=10),
        daemon=True,
    ).start()
    return jsonify({"ok": True, "rebooting": True})


# Started last, after every function above (including _nmcli) is defined -
# avoids a NameError race if a thread's first loop iteration runs before
# module loading finishes.
threading.Thread(target=_sample_fast, daemon=True).start()
threading.Thread(target=_sample_slow, daemon=True).start()
threading.Thread(target=_sample_net, daemon=True).start()
threading.Thread(target=_sample_disk, daemon=True).start()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8088)
