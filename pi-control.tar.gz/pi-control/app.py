"""Pi Control - lightweight system dashboard for the Pi."""
import calendar
import ipaddress
import json
import logging
import mimetypes
import os
import re
import secrets
import sqlite3
import subprocess
import time
import threading
from collections import deque
from datetime import timedelta

from flask import Flask, jsonify, redirect, render_template, request, send_from_directory, session
from werkzeug.security import check_password_hash, generate_password_hash
import feedparser
import psutil
import trafilatura

# waitress-serve runs this app under systemd, which captures stderr into the
# journal automatically - basicConfig with no extra handler config is enough
# to make an unhandled error in a background sampling loop show up in
# `journalctl -u picontrol` instead of vanishing into a bare `except: pass`.
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

mimetypes.add_type("application/epub+zip", ".epub")

app = Flask(__name__)

HELPER = "/usr/local/bin/pi-control-helper.sh"


def _static_max_age(filename):
    # Vendored third-party assets don't change between deploys - cache them
    # hard so a page refresh never re-fetches the 200KB Chart.js bundle.
    # Our own app.js/style.css change often during development, so those
    # keep the default (always-revalidate) behavior.
    if filename and filename.replace("\\", "/").startswith("vendor/"):
        return 60 * 60 * 24 * 365
    return None


app.get_send_file_max_age = _static_max_age

AUTH_SESSION_DAYS = 30


@app.before_request
def _require_login():
    # /login itself and static assets need to stay reachable while logged
    # out; /api/auth/check is nginx's auth_request probe (see nginx config
    # notes in RUNBOOK.md) - falling through to a plain 401 for it when
    # unauthenticated, same as any other /api/ route, is exactly what
    # auth_request needs to see.
    if request.path == "/login" or request.path.startswith("/static/"):
        return
    if not session.get("auth"):
        if request.path.startswith("/api/"):
            return jsonify({"ok": False, "error": "auth required"}), 401
        return redirect("/login")


# Synchronizer-token CSRF guard for the state-changing /api/ POST routes.
# Per-session (not a single process-wide constant) now that real sessions
# exist - a process-global token meant any leak of it was valid forever for
# every visitor until the next redeploy; scoping it to the session cookie
# means it's only ever as good as that one login. Embedded in index.html and
# echoed back by the frontend as the X-CSRF-Token header on every POST.
def _get_csrf_token():
    token = session.get("csrf_token")
    if not token:
        token = secrets.token_hex(32)
        session["csrf_token"] = token
    return token


@app.before_request
def _check_csrf():
    if request.method == "POST" and request.path.startswith("/api/"):
        if request.headers.get("X-CSRF-Token") != session.get("csrf_token"):
            return jsonify({"ok": False, "error": "invalid csrf token"}), 403

SERVICES = [
    ("AdGuardHome", "AdGuard"),
    ("unbound", "Unbound"),
    ("vaultwarden", "Vaultwarden"),
    ("tailscaled", "Tailscale"),
    ("nginx", "Nginx"),
    ("ufw", "UFW"),
    ("fail2ban", "Fail2Ban"),
]

# Rolling in-memory history for the performance trends chart (~1hr at 60s samples)
HISTORY = deque(maxlen=60)

# Longer-term trend history, downsampled to one row every 5min and persisted
# to disk - the in-memory HISTORY above only covers the last hour and is lost
# on every restart. 30 days at 5min resolution is a few thousand tiny rows,
# negligible against a 32GB card with 26GB free.
TRENDS_DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "trends.db")
TRENDS_RETENTION_DAYS = 30


# Long-term trends is a nice-to-have on top of the always-on in-memory
# HISTORY - if the working directory isn't writable by the service user (or
# any other sqlite issue comes up), it must degrade quietly rather than take
# the whole app down at import time.
TRENDS_DB_AVAILABLE = True


ALERT_HISTORY_KEEP = 200  # alerts are rare, so a row cap is simpler than time-based retention


def _init_trends_db():
    # Same db file also holds settings (persisted threshold overrides) and
    # alert_history - one file, three tables, all covered by the same
    # write-failure guard so a non-writable directory can't crash the app.
    global TRENDS_DB_AVAILABLE
    try:
        conn = sqlite3.connect(TRENDS_DB_PATH)
        conn.execute(
            "CREATE TABLE IF NOT EXISTS trends "
            "(ts INTEGER PRIMARY KEY, temp REAL, cpu REAL, ram REAL, swap REAL)"
        )
        conn.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
        conn.execute(
            "CREATE TABLE IF NOT EXISTS alert_history "
            "(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, message TEXT)"
        )
        conn.execute(
            "CREATE TABLE IF NOT EXISTS feeds "
            "(id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT UNIQUE, title TEXT, added_ts INTEGER)"
        )
        conn.execute(
            "CREATE TABLE IF NOT EXISTS articles "
            "(id INTEGER PRIMARY KEY AUTOINCREMENT, feed_id INTEGER, title TEXT, url TEXT UNIQUE, "
            "summary TEXT, published_ts INTEGER, fetched_ts INTEGER, saved INTEGER DEFAULT 0)"
        )
        conn.commit()
        conn.close()
    except Exception:
        TRENDS_DB_AVAILABLE = False


def _persist_trend_sample(temp, cpu, ram, swap):
    if not TRENDS_DB_AVAILABLE:
        return
    now = int(time.time())
    conn = sqlite3.connect(TRENDS_DB_PATH)
    conn.execute(
        "INSERT OR REPLACE INTO trends (ts, temp, cpu, ram, swap) VALUES (?, ?, ?, ?, ?)",
        (now, temp, cpu, ram, swap),
    )
    conn.execute("DELETE FROM trends WHERE ts < ?", (now - TRENDS_RETENTION_DAYS * 86400,))
    conn.commit()
    conn.close()


def _load_setting(key, default, cast=float):
    if not TRENDS_DB_AVAILABLE:
        return default
    try:
        conn = sqlite3.connect(TRENDS_DB_PATH)
        row = conn.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
        conn.close()
        return cast(row[0]) if row else default
    except Exception:
        return default


def _save_setting(key, value):
    if not TRENDS_DB_AVAILABLE:
        return
    try:
        conn = sqlite3.connect(TRENDS_DB_PATH)
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, str(value)))
        conn.commit()
        conn.close()
    except Exception:
        pass


def _record_alert_history(message):
    if not TRENDS_DB_AVAILABLE:
        return
    try:
        conn = sqlite3.connect(TRENDS_DB_PATH)
        conn.execute(
            "INSERT INTO alert_history (ts, message) VALUES (?, ?)", (int(time.time()), message)
        )
        conn.execute(
            "DELETE FROM alert_history WHERE id NOT IN "
            "(SELECT id FROM alert_history ORDER BY id DESC LIMIT ?)",
            (ALERT_HISTORY_KEEP,),
        )
        conn.commit()
        conn.close()
    except Exception:
        pass


def _cpu_temp():
    try:
        with open("/sys/class/thermal/thermal_zone0/temp") as f:
            return round(int(f.read().strip()) / 1000, 1)
    except Exception:
        return None


def _sample_loop():
    sample_count = 0
    while True:
        try:
            HISTORY.append({
                "t": time.strftime("%H:%M"),
                "temp": _cpu_temp(),
                "cpu": psutil.cpu_percent(interval=None),
                "ram": psutil.virtual_memory().percent,
            })
            sample_count += 1
            if sample_count % 5 == 0:
                recent = list(HISTORY)[-5:]
                temps = [s["temp"] for s in recent if s["temp"] is not None]
                cpus = [s["cpu"] for s in recent]
                rams = [s["ram"] for s in recent]
                _persist_trend_sample(
                    round(sum(temps) / len(temps), 1) if temps else None,
                    round(sum(cpus) / len(cpus), 1) if cpus else None,
                    round(sum(rams) / len(rams), 1) if rams else None,
                    psutil.swap_memory().percent,
                )
        except Exception:
            logger.exception("_sample_loop iteration failed")
        time.sleep(60)


_init_trends_db()

# Persisted in the same settings table as the alert thresholds so a login
# session survives a restart/redeploy - regenerating it every start would
# silently log everyone out every time this app gets redeployed, which given
# how often that happens during development would make "remember me for 30
# days" a lie.
_secret_key = _load_setting("flask_secret_key", None, cast=str)
if not _secret_key:
    _secret_key = secrets.token_hex(32)
    _save_setting("flask_secret_key", _secret_key)
app.secret_key = _secret_key
app.config.update(
    SESSION_COOKIE_SECURE=True,  # nginx terminates TLS in front of this app
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    PERMANENT_SESSION_LIFETIME=timedelta(days=AUTH_SESSION_DAYS),
)

threading.Thread(target=_sample_loop, daemon=True).start()


# Shared cache, populated by background threads so requests never block on
# subprocess spawns - the API just serves whatever was last computed.
CACHE_LOCK = threading.Lock()
CACHE = {
    "live": {"cpu_load": 0, "temp": None, "ram_pct": 0, "ram_used_mb": 0,
              "ram_total_mb": 0, "avg_load": [0, 0, 0],
              "swap_pct": 0, "swap_used_mb": 0, "swap_total_mb": 0},
    "services": [],
    "unbound": {"hit_rate": None, "hits": None, "misses": None},
    "cores": [],
    "top_procs": [],
    "top_mem_procs": [],
    "net_ifaces": [],
    "proton": {"up": False, "handshake_age_s": None, "rx_mb": None, "tx_mb": None},
    "net": {"mode": "unknown", "saved_networks": [], "available_networks": [],
             "ts_self_offers_exit": False, "ts_peers": []},
    "disk": {"arrays": [], "reclaim": []},
    "power": {"undervoltage_now": False, "freq_capped_now": False, "throttled_now": False,
               "undervoltage_occurred": False, "freq_capped_occurred": False, "throttled_occurred": False},
    "system_events": [],
    "zram": None,
    "fail2ban_banned": [],
}


def _service_statuses():
    """One batched systemctl call for all units, instead of one call each."""
    units = [u for u, _ in SERVICES]
    blocks = []
    try:
        out = subprocess.run(
            ["systemctl", "show", *units, "--property=ActiveState,MainPID,MemoryCurrent"],
            capture_output=True, text=True, timeout=5,
        ).stdout
        blocks = out.strip().split("\n\n")
    except Exception:
        pass

    ufw_active = False
    try:
        ufw_out = subprocess.run(["sudo", HELPER, "ufw-status"], capture_output=True, text=True, timeout=5).stdout
        ufw_active = "Status: active" in ufw_out
    except Exception:
        pass

    results = []
    for i, (unit, label) in enumerate(SERVICES):
        props = {}
        if i < len(blocks):
            props = dict(line.split("=", 1) for line in blocks[i].strip().splitlines() if "=" in line)

        # UFW's unit is a one-shot script that exits after applying rules -
        # ActiveState goes back to "inactive" even though the firewall is
        # still live, so it needs its own real status check.
        active = ufw_active if unit == "ufw" else props.get("ActiveState") == "active"

        mem = props.get("MemoryCurrent", "0")
        if mem.isdigit() and int(mem) > 0:
            mem_mb = round(int(mem) / (1024 * 1024), 1)
        else:
            # MemoryCurrent is often unset unless cgroup accounting is
            # explicitly enabled - fall back to reading the process directly.
            mem_mb = 0
            pid = props.get("MainPID", "0")
            if pid.isdigit() and int(pid) > 0:
                try:
                    mem_mb = round(psutil.Process(int(pid)).memory_info().rss / (1024 * 1024), 1)
                except Exception:
                    mem_mb = 0

        results.append({"unit": unit, "label": label, "active": active, "mem_mb": mem_mb})
    return results


NET_INTERFACES = ["eth0", "wlan0", "tailscale0", "proton"]


def _net_iface_stats():
    counters = psutil.net_io_counters(pernic=True)
    result = []
    for name in NET_INTERFACES:
        if name == "proton":
            # wg-quick derives the interface name from the config file
            # (proton-us.conf -> interface "proton-us"), so there's no
            # single fixed name here the way there is for eth0/wlan0 -
            # look up whichever proton-<server> interface actually exists.
            real_name = next((k for k in counters if k.startswith("proton-")), None)
            c = counters.get(real_name) if real_name else None
            result.append({
                "iface": real_name or "proton",
                "rx_mb": round(c.bytes_recv / (1024 * 1024), 1) if c else None,
                "tx_mb": round(c.bytes_sent / (1024 * 1024), 1) if c else None,
            })
            continue
        c = counters.get(name)
        result.append({
            "iface": name,
            "rx_mb": round(c.bytes_recv / (1024 * 1024), 1) if c else None,
            "tx_mb": round(c.bytes_sent / (1024 * 1024), 1) if c else None,
        })
    return result


def _proton_status():
    try:
        out = subprocess.run(["sudo", HELPER, "proton-status"], capture_output=True, text=True, timeout=5).stdout
    except Exception:
        out = ""
    out = out.strip()
    if not out or out == "not_configured":
        return {"up": False, "active_server": None, "handshake_age_s": None, "rx_mb": None, "tx_mb": None}

    lines = out.splitlines()
    if not lines or not lines[0].startswith("ACTIVE:"):
        return {"up": False, "active_server": None, "handshake_age_s": None, "rx_mb": None, "tx_mb": None}

    active_server = lines[0].split(":", 1)[1].replace("proton-", "", 1)

    if len(lines) < 3:
        return {"up": True, "active_server": active_server, "handshake_age_s": None, "rx_mb": None, "tx_mb": None}

    # lines[1] is wg's own interface line, lines[2] is the first peer
    peer = lines[2].split("\t")
    if len(peer) < 7:
        return {"up": True, "active_server": active_server, "handshake_age_s": None, "rx_mb": None, "tx_mb": None}

    latest_handshake = int(peer[4]) if peer[4].isdigit() else 0
    rx = int(peer[5]) if peer[5].isdigit() else 0
    tx = int(peer[6]) if peer[6].isdigit() else 0
    age = round(time.time() - latest_handshake) if latest_handshake > 0 else None

    return {
        "up": True,
        "active_server": active_server,
        "handshake_age_s": age,
        "rx_mb": round(rx / (1024 * 1024), 1),
        "tx_mb": round(tx / (1024 * 1024), 1),
    }


# vcgencmd get_throttled bit layout: bits 0-3 are the current state, bits
# 16-19 are "has this happened at least once since boot" - see
# https://www.raspberrypi.com/documentation/computers/os.html#get_throttled
def _power_status():
    default = {"undervoltage_now": False, "freq_capped_now": False, "throttled_now": False,
               "undervoltage_occurred": False, "freq_capped_occurred": False, "throttled_occurred": False}
    try:
        out = subprocess.run(["sudo", HELPER, "throttled"], capture_output=True, text=True, timeout=5).stdout.strip()
        value = int(out.split("=", 1)[1], 16)
    except Exception:
        return default
    return {
        "undervoltage_now": bool(value & (1 << 0)),
        "freq_capped_now": bool(value & (1 << 1)),
        "throttled_now": bool(value & (1 << 2)),
        "undervoltage_occurred": bool(value & (1 << 16)),
        "freq_capped_occurred": bool(value & (1 << 17)),
        "throttled_occurred": bool(value & (1 << 18)),
    }


# ---- proactive Telegram alerts on state transitions ----
# Only fires when a condition newly becomes true (or clears), never on every
# poll - a flapping issue or an ongoing one must not spam. ALERT_STATE is
# seeded once at startup from the real current state (see
# _init_alert_state) so a service restart never re-alerts for conditions
# that already existed before the dashboard came up.
#
# Thresholds are live-tunable from the ALERTS tab instead of being fixed
# constants - editing these used to mean hand-editing app.py and a full
# redeploy just to test a value. Defaults below are used until a persisted
# override is loaded via _load_alert_thresholds() at startup.
ALERT_THRESHOLDS = {
    "temp_c": 75.0,
    "disk_pct": 90.0,
    # WireGuard re-keys roughly every 2min under active traffic - this
    # margin allows for idle gaps without false-alerting, while still
    # catching a tunnel that silently died (wg-quick doesn't tear the
    # interface down on peer unreachability, so `up` can stay true with a
    # dead connection).
    "stale_handshake_s": 300,
}


def _load_alert_thresholds():
    with CACHE_LOCK:
        for key in ALERT_THRESHOLDS:
            ALERT_THRESHOLDS[key] = _load_setting(f"alert_{key}", ALERT_THRESHOLDS[key])

ALERT_STATE = {
    "power": {"undervoltage_now": False, "freq_capped_now": False, "throttled_now": False},
    "fail2ban_banned": set(),
    "system_events_seen": set(),
    "temp_high": False,
    "disk_high": set(),
    "services": {},
    "proton_stale": False,
    # Not seeded from real state in _init_alert_state (would need
    # duplicating _sample_net's tailscale/nmcli parsing there) - defaults to
    # False, which matches what a true cold start would compute anyway
    # since CACHE's own defaults are False/False before _sample_net or
    # _sample_fast have run once.
    "killswitch_active": False,
}

# Service-down/proton-stale checks each involve a `sudo` subprocess spawn
# (sometimes several) every 3s - on a Pi Zero 2W under any transient load
# (an apt run, journald contention, a slow sudo lookup), a single one of
# those can occasionally hit its timeout and read back as "down"/"stale"
# even though nothing real changed, and that one bad poll used to be
# enough to fire a false DOWN alert immediately followed by a false UP a
# few seconds later. Require the SAME new reading to show up on
# ALERT_CONFIRM_POLLS consecutive ~3s polls before treating it as a real
# transition - cheap insurance against exactly that flapping, confirmed
# against real device Telegram logs (isolated single-service DOWN/UP
# pairs with nothing else changing at the same time).
ALERT_CONFIRM_POLLS = 2
_ALERT_PENDING = {"services": {}, "proton_stale": (False, 0)}

LAST_ALERT = {"message": None, "ts": None}


def _send_alert(message):
    with CACHE_LOCK:
        LAST_ALERT["message"] = message
        LAST_ALERT["ts"] = int(time.time())
    _record_alert_history(message)

    def _run():
        try:
            subprocess.run(
                ["sudo", HELPER, "telegram-alert", message], capture_output=True, text=True, timeout=15,
            )
        except Exception:
            pass

    threading.Thread(target=_run, daemon=True).start()


def _init_alert_state():
    """Seed ALERT_STATE from real current conditions before the sampling
    loops start, so a restart doesn't re-alert on things already true."""
    try:
        power = _power_status()
        ALERT_STATE["power"] = {k: power[k] for k in ("undervoltage_now", "freq_capped_now", "throttled_now")}
    except Exception:
        pass
    try:
        ALERT_STATE["fail2ban_banned"] = {(b["jail"], b["ip"]) for b in _fail2ban_banned()}
    except Exception:
        pass
    try:
        ALERT_STATE["system_events_seen"] = set(_system_events())
    except Exception:
        pass
    try:
        temp = _cpu_temp()
        ALERT_STATE["temp_high"] = bool(temp is not None and temp >= ALERT_THRESHOLDS["temp_c"])
    except Exception:
        pass
    try:
        high = set()
        for mount in ["/", "/boot/firmware"]:
            u = psutil.disk_usage(mount)
            if u.percent >= ALERT_THRESHOLDS["disk_pct"]:
                high.add(mount)
        ALERT_STATE["disk_high"] = high
    except Exception:
        pass
    try:
        ALERT_STATE["services"] = {s["unit"]: s["active"] for s in _service_statuses()}
    except Exception:
        pass
    try:
        proton = _proton_status()
        ALERT_STATE["proton_stale"] = bool(
            proton["up"] and proton["handshake_age_s"] is not None
            and proton["handshake_age_s"] > ALERT_THRESHOLDS["stale_handshake_s"]
        )
    except Exception:
        pass


def _sample_fast():
    """Every ~3s: cheap system stats + service status, all served from cache."""
    while True:
        try:
            load1, load5, load15 = psutil.getloadavg()
            vm = psutil.virtual_memory()
            sw = psutil.swap_memory()
            temp = _cpu_temp()
            new_power = _power_status()
            new_services = _service_statuses()
            new_proton = _proton_status()
            alerts = []
            with CACHE_LOCK:
                CACHE["live"] = {
                    "cpu_load": psutil.cpu_percent(interval=None),
                    "temp": temp,
                    "ram_pct": vm.percent,
                    "ram_used_mb": round(vm.used / (1024 * 1024)),
                    "ram_total_mb": round(vm.total / (1024 * 1024)),
                    "avg_load": [round(load1, 2), round(load5, 2), round(load15, 2)],
                    "swap_pct": sw.percent,
                    "swap_used_mb": round(sw.used / (1024 * 1024)),
                    "swap_total_mb": round(sw.total / (1024 * 1024)),
                }
                CACHE["cores"] = psutil.cpu_percent(percpu=True, interval=None)
                CACHE["services"] = new_services
                CACHE["net_ifaces"] = _net_iface_stats()
                CACHE["proton"] = new_proton
                CACHE["power"] = new_power

                prev_power = ALERT_STATE["power"]
                for flag, label in (("undervoltage_now", "undervoltage"),
                                     ("freq_capped_now", "frequency cap"),
                                     ("throttled_now", "throttling")):
                    if new_power[flag] and not prev_power[flag]:
                        alerts.append(f"Pi Control ALERT: {label} detected (active now)")
                    elif prev_power[flag] and not new_power[flag]:
                        alerts.append(f"Pi Control: {label} cleared")
                ALERT_STATE["power"] = {k: new_power[k] for k in
                                        ("undervoltage_now", "freq_capped_now", "throttled_now")}

                is_temp_high = temp is not None and temp >= ALERT_THRESHOLDS["temp_c"]
                if is_temp_high and not ALERT_STATE["temp_high"]:
                    alerts.append(f"Pi Control ALERT: CPU temp crossed {ALERT_THRESHOLDS['temp_c']}°C (currently {temp}°C)")
                elif ALERT_STATE["temp_high"] and not is_temp_high:
                    alerts.append(f"Pi Control: CPU temp back below {ALERT_THRESHOLDS['temp_c']}°C (currently {temp}°C)")
                ALERT_STATE["temp_high"] = is_temp_high

                down_now, up_now = [], []
                pending_services = _ALERT_PENDING["services"]
                for s in new_services:
                    unit, label, active = s["unit"], s["label"], s["active"]
                    confirmed_prev = ALERT_STATE["services"].get(unit, active)
                    candidate, streak = pending_services.get(unit, (confirmed_prev, 0))
                    if active == candidate:
                        streak = min(streak + 1, ALERT_CONFIRM_POLLS)
                    else:
                        candidate, streak = active, 1
                    pending_services[unit] = (candidate, streak)
                    if streak >= ALERT_CONFIRM_POLLS and candidate != confirmed_prev:
                        ALERT_STATE["services"][unit] = candidate
                        (up_now if candidate else down_now).append(label)
                if down_now:
                    alerts.append(f"Pi Control ALERT: service(s) DOWN: {', '.join(down_now)}")
                if up_now:
                    alerts.append(f"Pi Control: service(s) back UP: {', '.join(up_now)}")

                is_stale = bool(
                    new_proton["up"] and new_proton["handshake_age_s"] is not None
                    and new_proton["handshake_age_s"] > ALERT_THRESHOLDS["stale_handshake_s"]
                )
                confirmed_stale_prev = ALERT_STATE["proton_stale"]
                stale_candidate, stale_streak = _ALERT_PENDING["proton_stale"]
                if is_stale == stale_candidate:
                    stale_streak = min(stale_streak + 1, ALERT_CONFIRM_POLLS)
                else:
                    stale_candidate, stale_streak = is_stale, 1
                _ALERT_PENDING["proton_stale"] = (stale_candidate, stale_streak)
                if stale_streak >= ALERT_CONFIRM_POLLS and stale_candidate != confirmed_stale_prev:
                    ALERT_STATE["proton_stale"] = stale_candidate
                    if stale_candidate:
                        alerts.append(
                            f"Pi Control ALERT: Proton ({new_proton['active_server']}) handshake stale "
                            f"- {new_proton['handshake_age_s']}s since last, tunnel may be dead"
                        )
                    else:
                        alerts.append("Pi Control: Proton handshake fresh again")
            for msg in alerts:
                _send_alert(msg)
        except Exception:
            logger.exception("_sample_fast iteration failed")
        time.sleep(3)


def _system_events():
    """OOM kills + undervoltage transitions + failover events, last 24h, merged
    and time-sorted by the helper - cheap, not time-critical."""
    try:
        out = subprocess.run(["sudo", HELPER, "system-events"], capture_output=True, text=True, timeout=10).stdout
    except Exception:
        return []
    return [line.strip() for line in out.splitlines() if line.strip()][-20:]


def _zram_stats():
    try:
        out = subprocess.run(["sudo", HELPER, "zram-stats"], capture_output=True, text=True, timeout=5).stdout.strip()
        name, disksize, data, compr = out.split()
        disksize, data, compr = int(disksize), int(data), int(compr)
    except Exception:
        return None
    return {
        "disksize_mb": round(disksize / (1024 * 1024), 1),
        "data_mb": round(data / (1024 * 1024), 1),
        "compr_mb": round(compr / (1024 * 1024), 1),
        "ratio": round(data / compr, 2) if compr > 0 else None,
    }


def _fail2ban_banned():
    try:
        out = subprocess.run(["sudo", HELPER, "fail2ban-banned"], capture_output=True, text=True, timeout=10).stdout
    except Exception:
        return []
    result = []
    for line in out.splitlines():
        line = line.strip()
        if ":" not in line:
            continue
        jail, ip = line.split(":", 1)
        if jail and ip:
            result.append({"jail": jail, "ip": ip})
    return result


def _sample_slow():
    """Every ~15s: unbound stats (needs sudo, slower) + top memory-using processes."""
    while True:
        # This loop had no outer catch-all before - an exception anywhere
        # below the unbound-stats try/except (e.g. in the CACHE_LOCK block)
        # would have silently killed this daemon thread forever, with
        # nothing but a bare traceback in stderr to explain why memory/OOM/
        # fail2ban data on the dashboard just stopped updating.
        try:
            unbound = {"hit_rate": None, "hits": None, "misses": None}
            try:
                out = subprocess.run(["sudo", HELPER, "unbound-stats"], capture_output=True, text=True, timeout=5).stdout
                stats = dict(line.split("=", 1) for line in out.splitlines() if "=" in line)
                hits = int(stats.get("total.num.cachehits", 0))
                misses = int(stats.get("total.num.cachemiss", 0))
                total = hits + misses
                unbound = {
                    "hit_rate": round(100 * hits / total, 1) if total else 0,
                    "hits": hits,
                    "misses": misses,
                }
            except Exception:
                pass

            cpu_procs, mem_procs = [], []
            for p in psutil.process_iter(["name", "cpu_percent", "memory_info"]):
                try:
                    mem_mb = round(p.info["memory_info"].rss / (1024 * 1024), 1) if p.info["memory_info"] else 0
                    cpu_procs.append((p.info["name"], p.info["cpu_percent"]))
                    mem_procs.append((p.info["name"], mem_mb))
                except Exception:
                    continue
            top_cpu = sorted(cpu_procs, key=lambda x: x[1] or 0, reverse=True)[:5]
            top_mem = sorted(mem_procs, key=lambda x: x[1] or 0, reverse=True)[:5]

            new_events = _system_events()
            new_banned = _fail2ban_banned()
            alerts = []
            with CACHE_LOCK:
                CACHE["unbound"] = unbound
                CACHE["top_procs"] = [{"name": n, "cpu_pct": c} for n, c in top_cpu if n]
                CACHE["top_mem_procs"] = [{"name": n, "mem_mb": m} for n, m in top_mem if n]
                CACHE["system_events"] = new_events
                CACHE["zram"] = _zram_stats()
                CACHE["fail2ban_banned"] = new_banned

                new_events_set = set(new_events)
                fresh_lines = new_events_set - ALERT_STATE["system_events_seen"]
                ALERT_STATE["system_events_seen"] = new_events_set
                # OOM lines only - undervoltage is already alerted via the
                # structured power-transition check above, and network-failover
                # lines are already alerted by the watchdog itself, so both are
                # skipped here to avoid double-alerting the same real event.
                oom_lines = [
                    l for l in fresh_lines
                    if ("Out of memory" in l or "Killed process" in l)
                    and "network-failover" not in l
                ]
                if oom_lines:
                    alerts.append("Pi Control ALERT: OOM kill(s) detected:\n" + "\n".join(oom_lines))

                # SD card health - block-layer/filesystem errors, disjoint from
                # the OOM/failover patterns above so no double-alerting risk.
                sd_lines = [
                    l for l in fresh_lines
                    if ("mmcblk" in l or "Buffer I/O error" in l or "EXT4-fs" in l)
                    and "network-failover" not in l
                ]
                if sd_lines:
                    alerts.append("Pi Control ALERT: possible SD card issue detected:\n" + "\n".join(sd_lines))

                new_banned_set = {(b["jail"], b["ip"]) for b in new_banned}
                newly_banned = new_banned_set - ALERT_STATE["fail2ban_banned"]
                ALERT_STATE["fail2ban_banned"] = new_banned_set
                if newly_banned:
                    lines = "\n".join(f"{ip} (jail: {jail})" for jail, ip in newly_banned)
                    alerts.append(f"Pi Control ALERT: fail2ban banned {len(newly_banned)} new IP(s):\n{lines}")
            for msg in alerts:
                _send_alert(msg)
        except Exception:
            logger.exception("_sample_slow iteration failed")
        time.sleep(15)


def _sample_net():
    """Every ~8s: nmcli (can be slow, especially a wifi scan) + tailscale status."""
    scan_count = 0
    while True:
        try:
            status = _nmcli("-t", "-f", "DEVICE,TYPE,STATE,CONNECTION", "device", "status")
            mode = "unknown"
            for line in status.splitlines():
                parts = line.split(":")
                if len(parts) >= 4 and parts[0] == "eth0" and parts[2] == "connected":
                    mode = "ethernet"
                elif len(parts) >= 4 and parts[0] == "wlan0" and parts[2] == "connected":
                    mode = "ap (failover)" if parts[3] == "wlan0-ap" else "wifi-client"

            saved = []
            for line in _nmcli("-t", "-f", "NAME,TYPE", "connection", "show").splitlines():
                parts = line.split(":")
                if len(parts) >= 2 and parts[1] == "802-11-wireless" and parts[0] != "wlan0-ap":
                    saved.append(parts[0])

            # A forced active scan takes the radio off-channel for a beat,
            # which can interrupt current wlan0 traffic (client or the
            # AP-failover mode) - only do a real one once every ~64s
            # (every 8th 8s poll); the rest just re-read NetworkManager's
            # existing cached scan results via --rescan no.
            scan_count += 1
            rescan = "yes" if scan_count % 8 == 1 else "no"
            available = []
            for line in _nmcli("-t", "-f", "SSID,SECURITY,SIGNAL", "device", "wifi", "list", "--rescan", rescan).splitlines():
                parts = line.split(":")
                if len(parts) >= 3 and parts[0]:
                    available.append({"ssid": parts[0], "security": parts[1] or "Open", "signal": parts[2]})

            self_offers_exit = False
            peers = []
            try:
                out = subprocess.run(["sudo", HELPER, "tailscale-status"], capture_output=True, text=True, timeout=10).stdout
                data = json.loads(out)
                self_info = data.get("Self", {}) or {}
                self_offers_exit = bool(self_info.get("ExitNodeOption", False))
                peers_raw = data.get("Peer", {}) or {}
                for _, p in peers_raw.items():
                    ips = p.get("TailscaleIPs") or []
                    peers.append({
                        "hostname": p.get("HostName", "unknown"),
                        "ip": ips[0] if ips else None,
                        "online": bool(p.get("Online", False)),
                    })
                peers.sort(key=lambda x: (not x["online"], x["hostname"]))
            except Exception:
                pass

            alerts = []
            with CACHE_LOCK:
                CACHE["net"] = {
                    "mode": mode,
                    "saved_networks": saved,
                    "available_networks": available,
                    "ts_self_offers_exit": self_offers_exit,
                    "ts_peers": peers,
                }
                # Same condition as the NET tab's kill-switch warning banner -
                # peer traffic goes direct instead of through the geo-exit
                # while this is true, easy to miss since it's a passive UI
                # element unless someone's actually looking at the tab.
                proton_up = CACHE["proton"].get("up", False)
                killswitch_now = self_offers_exit and not proton_up
                if killswitch_now and not ALERT_STATE["killswitch_active"]:
                    alerts.append(
                        "Pi Control ALERT: exit node active, Proton is OFF - peer traffic is going direct"
                    )
                elif ALERT_STATE["killswitch_active"] and not killswitch_now:
                    alerts.append("Pi Control: kill-switch condition cleared")
                ALERT_STATE["killswitch_active"] = killswitch_now
            for msg in alerts:
                _send_alert(msg)
        except Exception:
            logger.exception("_sample_net iteration failed")
        time.sleep(8)


def _sample_disk():
    """Every ~30s: disk usage + reclaimable space (du walks a directory, not cheap)."""
    while True:
        # Same missing-catch-all gap as _sample_slow had - an exception
        # anywhere in here used to kill this daemon thread permanently with
        # no record beyond a bare stderr traceback.
        try:
            arrays = []
            for mount in ["/", "/boot/firmware"]:
                try:
                    u = psutil.disk_usage(mount)
                    arrays.append({
                        "path": mount,
                        "used_gb": round(u.used / (1024 ** 3), 1),
                        "total_gb": round(u.total / (1024 ** 3), 1),
                        "pct": u.percent,
                    })
                except Exception:
                    continue

            reclaim = []
            for name, path in [("System Logs", "/var/log"), ("APT Cache", "/var/cache/apt")]:
                try:
                    out = subprocess.run(["du", "-sm", path], capture_output=True, text=True, timeout=15).stdout
                    size_mb = int(out.split()[0]) if out.strip() else 0
                except Exception:
                    size_mb = 0
                reclaim.append({"name": name, "path": path, "size_mb": size_mb})

            alerts = []
            with CACHE_LOCK:
                CACHE["disk"] = {"arrays": arrays, "reclaim": reclaim}
                for a in arrays:
                    mount, pct = a["path"], a["pct"]
                    is_high = pct >= ALERT_THRESHOLDS["disk_pct"]
                    was_high = mount in ALERT_STATE["disk_high"]
                    if is_high and not was_high:
                        ALERT_STATE["disk_high"].add(mount)
                        alerts.append(f"Pi Control ALERT: disk usage on {mount} crossed {ALERT_THRESHOLDS['disk_pct']}% (currently {pct}%)")
                    elif was_high and not is_high:
                        ALERT_STATE["disk_high"].discard(mount)
                        alerts.append(f"Pi Control: disk usage on {mount} back below {ALERT_THRESHOLDS['disk_pct']}% (currently {pct}%)")
            for msg in alerts:
                _send_alert(msg)
        except Exception:
            logger.exception("_sample_disk iteration failed")
        time.sleep(30)


def _overview_snapshot():
    # fail2ban_banned and the last-sent alert both moved off Overview (now
    # live on the SECURITY and ALERTS tabs respectively - see /api/security
    # and /api/alerts/history) - no longer duplicated in every page load.
    with CACHE_LOCK:
        return {
            "live": CACHE["live"],
            "services": CACHE["services"],
            "unbound": CACHE["unbound"],
            "power": CACHE["power"],
            "system_events": CACHE["system_events"],
            "zram": CACHE["zram"],
        }


def _auth_configured():
    return _load_setting("auth_password_hash", None, cast=str) is not None


# Small in-memory sliding-window limiter for /login - no new dependency
# (flask-limiter) for what a plain dict + lock already covers at this scale.
# Only guards the real login path; setup_mode has nothing to brute-force
# (there's no password yet, first valid submission just creates the account).
LOGIN_MAX_ATTEMPTS = 5
LOGIN_WINDOW_S = 300
_login_failures = {}
_login_failures_lock = threading.Lock()


def _client_ip():
    # nginx sets X-Real-IP (see sites-available/pi-control) - request.remote_addr
    # alone would just be nginx's own loopback address for every client.
    return request.headers.get("X-Real-IP", request.remote_addr)


def _login_attempts_remaining(ip):
    now = time.time()
    with _login_failures_lock:
        recent = [t for t in _login_failures.get(ip, []) if now - t < LOGIN_WINDOW_S]
        _login_failures[ip] = recent
        return LOGIN_MAX_ATTEMPTS - len(recent)


def _record_login_failure(ip):
    with _login_failures_lock:
        _login_failures.setdefault(ip, []).append(time.time())


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("auth"):
        return redirect("/")

    setup_mode = not _auth_configured()
    error = None
    if request.method == "POST":
        ip = _client_ip()
        if not setup_mode and _login_attempts_remaining(ip) <= 0:
            error = f"Too many failed attempts - try again in a few minutes"
        else:
            username = (request.form.get("username") or "").strip()
            password = request.form.get("password") or ""
            if setup_mode:
                confirm = request.form.get("confirm") or ""
                if not username or not password:
                    error = "Username and password are required"
                elif password != confirm:
                    error = "Passwords do not match"
                elif len(password) < 8:
                    error = "Password must be at least 8 characters"
                else:
                    _save_setting("auth_username", username)
                    _save_setting("auth_password_hash", generate_password_hash(password))
                    session.clear()
                    session.permanent = True
                    session["auth"] = True
                    return redirect("/")
            else:
                stored_user = _load_setting("auth_username", "", cast=str)
                stored_hash = _load_setting("auth_password_hash", "", cast=str)
                if username == stored_user and stored_hash and check_password_hash(stored_hash, password):
                    session.clear()
                    session.permanent = True
                    session["auth"] = True
                    return redirect("/")
                _record_login_failure(ip)
                error = "Invalid username or password"
    return render_template("login.html", setup_mode=setup_mode, error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")


@app.route("/api/auth/check")
def api_auth_check():
    # Reached only when _require_login has already confirmed a valid
    # session - this is nginx's auth_request probe for the /terminal/
    # (ttyd) proxy, which sits on a separate port this app doesn't front,
    # so it needs its own way to ask "is this cookie logged in?"
    return "", 200


@app.route("/")
def index():
    # Embed the current overview snapshot straight into the page so the
    # Overview tab (the default view) paints with real data immediately,
    # instead of showing "--" placeholders until the first /api/overview
    # round-trip completes - that round-trip is what made refreshes feel
    # slow even after the apt-get/Chart.js fixes, since every tiny fetch
    # still pays full network latency over Tailscale.
    return render_template("index.html", csrf_token=_get_csrf_token(), overview=_overview_snapshot())


@app.route("/reader")
def reader():
    # Filename comes from the query string and is read client-side; epub.js
    # fetches it straight from /epubs/<filename>, which is already
    # path-traversal-safe via send_from_directory.
    return render_template("reader.html")


@app.route("/api/overview")
def api_overview():
    return jsonify(_overview_snapshot())


@app.route("/api/alerts/history")
def api_alerts_history():
    if not TRENDS_DB_AVAILABLE:
        return jsonify([])
    try:
        limit = max(1, min(int(request.args.get("limit", 100)), ALERT_HISTORY_KEEP))
    except ValueError:
        limit = 100
    try:
        conn = sqlite3.connect(TRENDS_DB_PATH)
        rows = conn.execute(
            "SELECT ts, message FROM alert_history ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        conn.close()
    except Exception:
        return jsonify([])
    return jsonify([{"ts": ts, "message": message} for ts, message in rows])


@app.route("/api/alerts/thresholds")
def api_alerts_thresholds():
    with CACHE_LOCK:
        return jsonify(dict(ALERT_THRESHOLDS))


@app.route("/api/action/alerts/thresholds", methods=["POST"])
def api_action_alerts_thresholds():
    body = request.json or {}
    # (key, minimum, maximum) - loose sanity bounds, not meant to be
    # restrictive, just to stop a typo from producing a threshold that can
    # never be crossed (or is always crossed).
    bounds = {
        "temp_c": (30.0, 90.0),
        "disk_pct": (50.0, 99.0),
        "stale_handshake_s": (60.0, 3600.0),
    }
    updated = {}
    for key, (lo, hi) in bounds.items():
        if key not in body:
            continue
        try:
            value = float(body[key])
        except (TypeError, ValueError):
            return jsonify({"ok": False, "error": f"invalid value for {key}"}), 400
        if not (lo <= value <= hi):
            return jsonify({"ok": False, "error": f"{key} must be between {lo} and {hi}"}), 400
        updated[key] = value
    with CACHE_LOCK:
        for key, value in updated.items():
            ALERT_THRESHOLDS[key] = value
    for key, value in updated.items():
        _save_setting(f"alert_{key}", value)
    return jsonify({"ok": True, "thresholds": dict(ALERT_THRESHOLDS)})


LOG_UNITS = {u for u, _ in SERVICES} | {"picontrol"}


@app.route("/api/logs")
def api_logs():
    unit = request.args.get("unit", "")
    if unit not in LOG_UNITS:
        return jsonify({"ok": False, "error": "unit not allowed"}), 400
    try:
        lines = max(10, min(int(request.args.get("lines", 100)), 500))
    except ValueError:
        lines = 100
    try:
        out = subprocess.run(
            ["sudo", HELPER, "service-logs", unit, str(lines)],
            capture_output=True, text=True, timeout=15,
        ).stdout
    except Exception:
        out = ""
    return jsonify({"ok": True, "unit": unit, "lines": out.splitlines()})


def _fail2ban_summary():
    try:
        out = subprocess.run(["sudo", HELPER, "fail2ban-summary"], capture_output=True, text=True, timeout=10).stdout
    except Exception:
        return []
    result = []
    for line in out.splitlines():
        parts = line.strip().split("|")
        if len(parts) != 5:
            continue
        jail, total_failed, total_banned, currently_failed, currently_banned = parts
        result.append({
            "jail": jail,
            "total_failed": int(total_failed) if total_failed.isdigit() else 0,
            "total_banned": int(total_banned) if total_banned.isdigit() else 0,
            "currently_failed": int(currently_failed) if currently_failed.isdigit() else 0,
            "currently_banned": int(currently_banned) if currently_banned.isdigit() else 0,
        })
    return result


@app.route("/api/security")
def api_security():
    try:
        ufw_rules = subprocess.run(
            ["sudo", HELPER, "ufw-rules"], capture_output=True, text=True, timeout=10
        ).stdout.splitlines()
    except Exception:
        ufw_rules = []
    try:
        ssh_log = subprocess.run(
            ["sudo", HELPER, "ssh-auth-log"], capture_output=True, text=True, timeout=10
        ).stdout.splitlines()
    except Exception:
        ssh_log = []
    with CACHE_LOCK:
        fail2ban_banned = CACHE["fail2ban_banned"]
    return jsonify({
        "ufw_rules": ufw_rules,
        "fail2ban_summary": _fail2ban_summary(),
        "fail2ban_banned": fail2ban_banned,
        "ssh_auth_log": ssh_log,
    })


@app.route("/api/action/restart/<unit>", methods=["POST"])
def api_restart(unit):
    allowed = {u for u, _ in SERVICES}
    if unit not in allowed:
        return jsonify({"ok": False, "error": "not allowed"}), 400
    result = subprocess.run(
        ["sudo", HELPER, "restart", unit], capture_output=True, text=True, timeout=15
    )
    return jsonify({"ok": result.returncode == 0, "output": result.stdout + result.stderr})


# Static tools served by their own nginx site (see RUNBOOK.md) that aren't
# always needed - toggling them off shrinks exposed surface (one less live
# listener) when not in use. Confirmed via a live before/after RAM check
# that this buys no memory back (they're just static files, no dedicated
# process), so the point is attack-surface reduction, not resources. Keep
# `name` in sync with ALLOWED_NGINX_SITES in pi-control-helper.sh.
NGINX_SITES = [
    {"name": "bentopdf", "label": "BentoPDF", "port": 9449},
    {"name": "omni-tools", "label": "OmniTools", "port": 9450},
]


@app.route("/api/sites/status")
def api_sites_status():
    sites = []
    for s in NGINX_SITES:
        try:
            out = subprocess.run(
                ["sudo", HELPER, "site-status", s["name"]], capture_output=True, text=True, timeout=5
            ).stdout.strip()
            enabled = out == "enabled"
        except Exception:
            enabled = False
        sites.append({**s, "enabled": enabled})
    return jsonify({"sites": sites})


@app.route("/api/action/sites/<site>/<action>", methods=["POST"])
def api_sites_toggle(site, action):
    if site not in {s["name"] for s in NGINX_SITES} or action not in ("enable", "disable"):
        return jsonify({"ok": False, "error": "invalid site or action"}), 400
    result = subprocess.run(
        ["sudo", HELPER, f"site-{action}", site], capture_output=True, text=True, timeout=15
    )
    return jsonify({"ok": result.returncode == 0, "output": (result.stdout + result.stderr).strip()})


@app.route("/api/action/validate/<unit>", methods=["POST"])
def api_validate(unit):
    # Only services with a known-safe config check (see Phase 7a's auth-loop
    # incident - broke twice from a manual YAML edit that was never
    # validated before restarting).
    if unit not in ("AdGuardHome", "unbound"):
        return jsonify({"ok": False, "error": "not allowed"}), 400
    result = subprocess.run(
        ["sudo", HELPER, "validate-config", unit], capture_output=True, text=True, timeout=15
    )
    return jsonify({"ok": result.returncode == 0, "output": result.stdout + result.stderr})


@app.route("/api/action/fail2ban/unban", methods=["POST"])
def api_fail2ban_unban():
    body = request.json or {}
    jail = body.get("jail", "")
    ip = body.get("ip", "")
    if not re.fullmatch(r"[A-Za-z0-9_-]+", jail or ""):
        return jsonify({"ok": False, "error": "invalid jail"}), 400
    try:
        ipaddress.ip_address(ip)
    except ValueError:
        return jsonify({"ok": False, "error": "invalid ip"}), 400
    result = subprocess.run(
        ["sudo", HELPER, "fail2ban-unban", jail, ip], capture_output=True, text=True, timeout=10
    )
    return jsonify({"ok": result.returncode == 0, "output": result.stdout + result.stderr})


@app.route("/api/sys")
def api_sys():
    uptime_s = time.time() - psutil.boot_time()
    days, rem = divmod(uptime_s, 86400)
    hours, rem = divmod(rem, 3600)
    minutes = rem // 60

    try:
        freq = psutil.cpu_freq().current
    except Exception:
        freq = None

    with CACHE_LOCK:
        return jsonify({
            "trends": list(HISTORY),
            "uptime": f"{int(days)}d {int(hours)}h {int(minutes)}m",
            "cpu_freq": round(freq) if freq else None,
            "cores": CACHE["cores"],
            "top_procs": CACHE["top_procs"],
            "top_mem_procs": CACHE["top_mem_procs"],
        })


@app.route("/api/trends/long")
def api_trends_long():
    if not TRENDS_DB_AVAILABLE:
        return jsonify([])
    try:
        days = max(1, min(int(request.args.get("days", 7)), TRENDS_RETENTION_DAYS))
    except ValueError:
        days = 7
    cutoff = int(time.time()) - days * 86400
    try:
        conn = sqlite3.connect(TRENDS_DB_PATH)
        rows = conn.execute(
            "SELECT ts, temp, cpu, ram, swap FROM trends WHERE ts >= ? ORDER BY ts", (cutoff,)
        ).fetchall()
        conn.close()
    except Exception:
        return jsonify([])
    return jsonify([
        {"ts": ts, "temp": temp, "cpu": cpu, "ram": ram, "swap": swap}
        for ts, temp, cpu, ram, swap in rows
    ])


# ---- system updates (background job, since full-upgrade can run long) ----
UPDATE_STATE = {"running": False, "output": "", "done_ok": None, "kind": None}
UPDATE_LOCK = threading.Lock()

# apt-check hits the network (apt-get update) - too slow to run inline on
# every page load, so it's cached and refreshed on its own schedule. The
# CHECK button forces an immediate on-demand refresh via /recheck instead.
UPDATE_CHECK_LOCK = threading.Lock()
UPDATE_CHECK_CACHE = {"ok": True, "upgradable": 0}


def _run_apt_check():
    result = subprocess.run(["sudo", HELPER, "apt-check"], capture_output=True, text=True, timeout=60)
    count_line = result.stdout.strip().splitlines()[-1] if result.stdout.strip() else "0"
    try:
        count = int(count_line)
    except ValueError:
        count = 0
    return {"ok": result.returncode == 0, "upgradable": count}


def _sample_updates():
    """Every ~30min: refresh the apt-update-count cache off the request path."""
    while True:
        try:
            result = _run_apt_check()
            with UPDATE_CHECK_LOCK:
                UPDATE_CHECK_CACHE.update(result)
        except Exception:
            logger.exception("_sample_updates iteration failed")
        time.sleep(1800)


@app.route("/api/updates/check")
def api_updates_check():
    with UPDATE_CHECK_LOCK:
        return jsonify(dict(UPDATE_CHECK_CACHE))


@app.route("/api/updates/recheck", methods=["POST"])
def api_updates_recheck():
    result = _run_apt_check()
    with UPDATE_CHECK_LOCK:
        UPDATE_CHECK_CACHE.update(result)
    return jsonify(result)


def _run_upgrade(kind):
    action = "full-upgrade" if kind == "full" else "normal-upgrade"
    with UPDATE_LOCK:
        UPDATE_STATE["running"] = True
        UPDATE_STATE["output"] = ""
        UPDATE_STATE["done_ok"] = None
        UPDATE_STATE["kind"] = kind
    result = subprocess.run(
        ["sudo", HELPER, action], capture_output=True, text=True, timeout=1800
    )
    with UPDATE_LOCK:
        UPDATE_STATE["running"] = False
        UPDATE_STATE["output"] = (result.stdout + result.stderr)[-4000:]
        UPDATE_STATE["done_ok"] = result.returncode == 0


@app.route("/api/updates/upgrade", methods=["POST"])
def api_updates_upgrade():
    kind = (request.json or {}).get("kind", "full")
    if kind not in ("normal", "full"):
        return jsonify({"ok": False, "error": "invalid kind"}), 400
    with UPDATE_LOCK:
        if UPDATE_STATE["running"]:
            return jsonify({"ok": False, "error": "already running"}), 409
    threading.Thread(target=_run_upgrade, args=(kind,), daemon=True).start()
    return jsonify({"ok": True, "started": True, "kind": kind})


@app.route("/api/updates/status")
def api_updates_status():
    with UPDATE_LOCK:
        return jsonify(dict(UPDATE_STATE))


def _nmcli(*args):
    return subprocess.run(["nmcli", *args], capture_output=True, text=True, timeout=10).stdout


@app.route("/api/net")
def api_net():
    with CACHE_LOCK:
        net = dict(CACHE.get("net", {}))
        net["net_ifaces"] = CACHE.get("net_ifaces", [])
        net["proton"] = CACHE.get("proton", {})
    return jsonify(net)


@app.route("/api/action/wifi/connect_saved", methods=["POST"])
def api_wifi_connect_saved():
    ssid = (request.json or {}).get("ssid", "")
    result = subprocess.run(
        ["sudo", HELPER, "connect-saved", ssid], capture_output=True, text=True, timeout=20
    )
    return jsonify({"ok": result.returncode == 0, "output": result.stdout + result.stderr})


@app.route("/api/action/wifi/connect_new", methods=["POST"])
def api_wifi_connect_new():
    body = request.json or {}
    ssid = body.get("ssid", "")
    password = body.get("password", "")
    # Password goes over stdin, not argv - a CLI arg would be visible to any
    # local user via `ps`/`/proc/<pid>/cmdline` for the life of the process.
    result = subprocess.run(
        ["sudo", HELPER, "connect-new", ssid],
        input=password + "\n", capture_output=True, text=True, timeout=20,
    )
    return jsonify({"ok": result.returncode == 0, "output": result.stdout + result.stderr})


@app.route("/api/disk")
def api_disk():
    with CACHE_LOCK:
        return jsonify(dict(CACHE.get("disk", {"arrays": [], "reclaim": []})))


@app.route("/api/action/clean/<target>", methods=["POST"])
def api_clean(target):
    if target not in ("logs", "apt"):
        return jsonify({"ok": False, "error": "not allowed"}), 400
    result = subprocess.run(
        ["sudo", HELPER, f"clean-{target}"], capture_output=True, text=True, timeout=30
    )
    return jsonify({"ok": result.returncode == 0, "output": result.stdout + result.stderr})


@app.route("/api/proton/servers")
def api_proton_servers():
    try:
        out = subprocess.run(["sudo", HELPER, "proton-list"], capture_output=True, text=True, timeout=10).stdout
        servers = [s.strip() for s in out.splitlines() if s.strip()]
    except Exception:
        servers = []
    return jsonify({"servers": servers})


@app.route("/api/action/proton/switch", methods=["POST"])
def api_proton_switch():
    server = (request.json or {}).get("server", "")
    if not server or not server.replace("-", "").isalnum():
        return jsonify({"ok": False, "error": "invalid server name"}), 400
    result = subprocess.run(
        ["sudo", HELPER, "proton-switch", server], capture_output=True, text=True, timeout=20
    )
    return jsonify({"ok": result.returncode == 0, "output": result.stdout + result.stderr})


@app.route("/api/action/proton/off", methods=["POST"])
def api_proton_off():
    result = subprocess.run(["sudo", HELPER, "proton-off"], capture_output=True, text=True, timeout=20)
    return jsonify({"ok": result.returncode == 0, "output": result.stdout + result.stderr})


@app.route("/api/net/egress")
def api_net_egress():
    # -4 forced on both checks below - Proton is IPv4-only (Phase 6), so an
    # IPv6 "direct" result wouldn't be a meaningful comparison against the
    # exit-node path even if it happened to be technically correct.
    direct_ip = None
    try:
        direct_ip = subprocess.run(
            ["curl", "-4", "-s", "--max-time", "5", "https://ifconfig.me"],
            capture_output=True, text=True, timeout=8,
        ).stdout.strip() or None
    except Exception:
        pass

    # Binding to a specific interface (SO_BINDTODEVICE) needs CAP_NET_RAW,
    # which this unprivileged process doesn't have - route through the
    # sudo helper for this one check only.
    # timeout=15 gives headroom over the helper's own worst case (5s getent
    # + 8s curl --max-time = 13s) so the outer timeout doesn't fire first and
    # swallow the helper's own diagnostic output.
    exit_path_ip = None
    try:
        result = subprocess.run(
            ["sudo", HELPER, "egress-exit"], capture_output=True, text=True, timeout=15,
        )
        exit_path_ip = (result.stdout + result.stderr).strip() or None
    except Exception:
        pass

    return jsonify({"direct_ip": direct_ip, "exit_path_ip": exit_path_ip})


@app.route("/api/action/telegram/test", methods=["POST"])
def api_telegram_test():
    result = subprocess.run(
        ["sudo", HELPER, "telegram-test"], capture_output=True, text=True, timeout=15
    )
    return jsonify({"ok": result.returncode == 0, "output": result.stdout + result.stderr})


@app.route("/api/action/reboot", methods=["POST"])
def api_reboot():
    threading.Thread(
        target=lambda: subprocess.run(["sudo", HELPER, "reboot"], capture_output=True, timeout=10),
        daemon=True,
    ).start()
    return jsonify({"ok": True, "rebooting": True})


# ---- RSS reader + article-to-EPUB pipeline ----
# Runs entirely as the unprivileged app user - no sudo helper actions needed,
# unlike most of the rest of this file, since fetching a feed/URL and
# running pandoc are both things `anon` can already do directly. The one
# privileged, one-time piece (Samba, so an e-reader can grab the EPUBs over
# the LAN) is set up manually - see RUNBOOK.md - not exposed through the
# dashboard since it's not something you'd toggle repeatedly.
ARTICLES_DIR = os.path.expanduser("~/Articles")
try:
    os.makedirs(ARTICLES_DIR, exist_ok=True)
except Exception:
    logger.exception("could not create ARTICLES_DIR")


def _slugify(title):
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", title or "").strip("-").lower()
    return slug[:80] or "article"


# trafilatura's own default User-Agent ("trafilatura/2.2.0 (+https://...)")
# self-identifies as a scraper, which sites like Medium block outright,
# turning into a plain "could not download the page" with no real
# indication why. Rotating through a few real desktop-browser UAs instead
# gets past that - confirmed against a local test server that 403s the
# default UA and 200s these before shipping this, rather than trusting it
# would work against a real site untested.
_TRAFILATURA_CONFIG = trafilatura.settings.use_config()
_TRAFILATURA_CONFIG.set(
    "DEFAULT",
    "USER_AGENTS",
    "\n".join([
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    ]),
)


def _generate_epub(url, fallback_title=None):
    """Fetch a URL, strip it down to clean article text, convert to EPUB.
    Returns (True, filename) or (False, error_message)."""
    try:
        # fetch_response (rather than the higher-level fetch_url) keeps the
        # real HTTP status around - fetch_url collapses every failure mode
        # (blocked, paywalled, connection error) into the same bare None,
        # which is exactly the unhelpful "could not download the page" this
        # was reported against. Surfacing the actual status lets a 403
        # (bot-blocked) be told apart from a 200-with-empty-content (likely
        # a login/paywall/JS-only wall trafilatura can't see past).
        response = trafilatura.fetch_response(url, decode=True, config=_TRAFILATURA_CONFIG)
        if not response:
            return False, "could not download the page (connection failed)"
        if response.status != 200:
            return False, f"could not download the page (site returned HTTP {response.status})"
        downloaded = response.html
        if not downloaded or len(downloaded) < 200:
            return False, "downloaded the page but it looked empty - likely a login wall, paywall, or JS-only page"
        md = trafilatura.extract(downloaded, output_format="markdown", url=url)
        if not md:
            return False, "could not extract article content from this page"
        meta = trafilatura.extract_metadata(downloaded, default_url=url)
        title = (meta.title if meta and meta.title else fallback_title) or url
        author = meta.author if meta else None
    except Exception as e:
        return False, str(e)

    slug = _slugify(title)
    ts = int(time.time())
    md_path = os.path.join(ARTICLES_DIR, f".{slug}-{ts}.md")
    epub_name = f"{slug}-{ts}.epub"
    epub_path = os.path.join(ARTICLES_DIR, epub_name)

    try:
        with open(md_path, "w") as f:
            f.write(f"# {title}\n\n")
            if author:
                f.write(f"*by {author}*\n\n")
            f.write(md)

        cmd = ["pandoc", md_path, "-o", epub_path, "--metadata", f"title={title}"]
        if author:
            cmd += ["--metadata", f"author={author}"]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if result.returncode != 0:
            return False, (result.stderr or "pandoc failed").strip()[-500:]
        return True, epub_name
    finally:
        try:
            os.remove(md_path)
        except OSError:
            pass


def _fetch_all_feeds():
    if not TRENDS_DB_AVAILABLE:
        return
    conn = sqlite3.connect(TRENDS_DB_PATH)
    feeds = conn.execute("SELECT id, url FROM feeds").fetchall()
    now = int(time.time())
    for feed_id, feed_url in feeds:
        try:
            parsed = feedparser.parse(feed_url)
            for entry in parsed.entries[:50]:
                link = entry.get("link")
                if not link:
                    continue
                title = entry.get("title", link)
                summary = (entry.get("summary", "") or "")[:500]
                published = entry.get("published_parsed")
                published_ts = int(calendar.timegm(published)) if published else now
                conn.execute(
                    "INSERT OR IGNORE INTO articles "
                    "(feed_id, title, url, summary, published_ts, fetched_ts) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (feed_id, title, link, summary, published_ts, now),
                )
        except Exception:
            logger.exception(f"failed to fetch feed {feed_url}")
    conn.commit()
    conn.close()


def _sample_feeds():
    """Every ~20min: poll subscribed RSS feeds for new articles."""
    while True:
        try:
            _fetch_all_feeds()
        except Exception:
            logger.exception("_sample_feeds iteration failed")
        time.sleep(1200)


@app.route("/api/feeds")
def api_feeds_list():
    if not TRENDS_DB_AVAILABLE:
        return jsonify({"feeds": []})
    conn = sqlite3.connect(TRENDS_DB_PATH)
    rows = conn.execute("SELECT id, url, title, added_ts FROM feeds ORDER BY title").fetchall()
    conn.close()
    return jsonify({"feeds": [{"id": r[0], "url": r[1], "title": r[2], "added_ts": r[3]} for r in rows]})


@app.route("/api/feeds", methods=["POST"])
def api_feeds_add():
    url = ((request.json or {}).get("url") or "").strip()
    if not url or not url.startswith(("http://", "https://")):
        return jsonify({"ok": False, "error": "invalid URL"}), 400
    try:
        parsed = feedparser.parse(url)
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    if parsed.bozo and not parsed.entries:
        return jsonify({"ok": False, "error": "could not parse as an RSS/Atom feed"}), 400
    title = parsed.feed.get("title", url)
    if not TRENDS_DB_AVAILABLE:
        return jsonify({"ok": False, "error": "storage unavailable"}), 500
    try:
        conn = sqlite3.connect(TRENDS_DB_PATH)
        conn.execute(
            "INSERT INTO feeds (url, title, added_ts) VALUES (?, ?, ?)", (url, title, int(time.time()))
        )
        conn.commit()
        conn.close()
    except sqlite3.IntegrityError:
        return jsonify({"ok": False, "error": "feed already subscribed"}), 400
    threading.Thread(target=_fetch_all_feeds, daemon=True).start()
    return jsonify({"ok": True, "title": title})


@app.route("/api/feeds/<int:feed_id>/delete", methods=["POST"])
def api_feeds_delete(feed_id):
    if not TRENDS_DB_AVAILABLE:
        return jsonify({"ok": False, "error": "storage unavailable"}), 500
    conn = sqlite3.connect(TRENDS_DB_PATH)
    conn.execute("DELETE FROM feeds WHERE id = ?", (feed_id,))
    conn.execute("DELETE FROM articles WHERE feed_id = ?", (feed_id,))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


@app.route("/api/articles")
def api_articles_list():
    if not TRENDS_DB_AVAILABLE:
        return jsonify({"articles": []})
    try:
        limit = max(10, min(int(request.args.get("limit", 50)), 200))
    except ValueError:
        limit = 50
    conn = sqlite3.connect(TRENDS_DB_PATH)
    rows = conn.execute(
        "SELECT a.id, a.title, a.url, a.summary, a.published_ts, a.saved, f.title "
        "FROM articles a LEFT JOIN feeds f ON a.feed_id = f.id "
        "ORDER BY a.published_ts DESC LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return jsonify({"articles": [
        {"id": r[0], "title": r[1], "url": r[2], "summary": r[3], "published_ts": r[4],
         "saved": bool(r[5]), "feed_title": r[6]}
        for r in rows
    ]})


@app.route("/api/articles/<int:article_id>/save", methods=["POST"])
def api_articles_save(article_id):
    if not TRENDS_DB_AVAILABLE:
        return jsonify({"ok": False, "error": "storage unavailable"}), 500
    conn = sqlite3.connect(TRENDS_DB_PATH)
    row = conn.execute("SELECT url, title FROM articles WHERE id = ?", (article_id,)).fetchone()
    if not row:
        conn.close()
        return jsonify({"ok": False, "error": "article not found"}), 404
    url, title = row
    ok, result = _generate_epub(url, fallback_title=title)
    if ok:
        conn.execute("UPDATE articles SET saved = 1 WHERE id = ?", (article_id,))
        conn.commit()
    conn.close()
    return jsonify({"ok": ok, "filename": result if ok else None, "error": None if ok else result})


@app.route("/api/save-url", methods=["POST"])
def api_save_url():
    url = ((request.json or {}).get("url") or "").strip()
    if not url or not url.startswith(("http://", "https://")):
        return jsonify({"ok": False, "error": "invalid URL"}), 400
    ok, result = _generate_epub(url)
    return jsonify({"ok": ok, "filename": result if ok else None, "error": None if ok else result})


@app.route("/api/epubs")
def api_epubs_list():
    try:
        files = []
        for name in os.listdir(ARTICLES_DIR):
            if not name.endswith(".epub"):
                continue
            path = os.path.join(ARTICLES_DIR, name)
            stat = os.stat(path)
            files.append({"name": name, "size_kb": round(stat.st_size / 1024, 1), "mtime": int(stat.st_mtime)})
        files.sort(key=lambda f: f["mtime"], reverse=True)
        return jsonify({"epubs": files})
    except Exception:
        return jsonify({"epubs": []})


@app.route("/epubs/<path:filename>")
def download_epub(filename):
    # send_from_directory rejects any filename that would resolve outside
    # ARTICLES_DIR - no separate path-traversal check needed here.
    return send_from_directory(ARTICLES_DIR, filename, as_attachment=True)


# Started last, after every function above (including _nmcli) is defined -
# avoids a NameError race if a thread's first loop iteration runs before
# module loading finishes.
_load_alert_thresholds()
_init_alert_state()
threading.Thread(target=_sample_fast, daemon=True).start()
threading.Thread(target=_sample_slow, daemon=True).start()
threading.Thread(target=_sample_net, daemon=True).start()
threading.Thread(target=_sample_disk, daemon=True).start()
threading.Thread(target=_sample_updates, daemon=True).start()
threading.Thread(target=_sample_feeds, daemon=True).start()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8088)
