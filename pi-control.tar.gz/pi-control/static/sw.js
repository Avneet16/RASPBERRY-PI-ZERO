// Exists only so Chrome counts this as an installable PWA (standalone
// launch, no browser chrome, from the home-screen icon) - this is a live
// system dashboard, so there's nothing here worth caching offline. Every
// request just passes straight through to the network.
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));
self.addEventListener("fetch", (event) => {
  event.respondWith(fetch(event.request));
});
