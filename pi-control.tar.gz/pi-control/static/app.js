function toast(message, isError = false) {
  const el = document.getElementById('toast');
  el.textContent = message;
  el.classList.toggle('error', isError);
  el.classList.add('show');
  clearTimeout(el._hideTimer);
  el._hideTimer = setTimeout(() => el.classList.remove('show'), 3200);
}

const tabButtons = document.querySelectorAll('#tabbar button');
const titleEl = document.getElementById('page-title');
const titles = { over: 'OVERVIEW', sys: 'SYSTEM DETAILS', net: 'LIVE NETWORK', disk: 'STORAGE ARRAYS', term: 'TERMINAL' };

const TAB_ORDER = ['over', 'sys', 'net', 'disk', 'term'];

function activateTab(name) {
  tabButtons.forEach(b => b.classList.toggle('active', b.dataset.tab === name));
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  titleEl.textContent = titles[name];
  localStorage.setItem('pc_active_tab', name);
  loadTab(name);
}

tabButtons.forEach(btn => {
  btn.addEventListener('click', () => activateTab(btn.dataset.tab));
});

// Swipe navigation: swipe left -> next tab, swipe right -> previous tab
let touchStartX = null;
let touchStartY = null;
let touchStartTarget = null;

document.body.addEventListener('touchstart', e => {
  touchStartX = e.changedTouches[0].screenX;
  touchStartY = e.changedTouches[0].screenY;
  touchStartTarget = e.target;
});

document.body.addEventListener('touchend', e => {
  if (touchStartX === null) return;
  const dx = e.changedTouches[0].screenX - touchStartX;
  const dy = e.changedTouches[0].screenY - touchStartY;
  touchStartX = null;

  // Ignore swipes that started on a button/input/select, or that are more
  // vertical than horizontal (likely a scroll, not a tab-swipe gesture).
  const startedOnControl = touchStartTarget && touchStartTarget.closest('button, input, select');
  if (startedOnControl) return;
  if (Math.abs(dx) < 70 || Math.abs(dx) < Math.abs(dy) * 1.5) return;

  const current = document.querySelector('#tabbar button.active').dataset.tab;
  let idx = TAB_ORDER.indexOf(current);
  if (dx < 0) idx = Math.min(idx + 1, TAB_ORDER.length - 1);
  else idx = Math.max(idx - 1, 0);
  activateTab(TAB_ORDER[idx]);
});

async function loadOverview() {
  const r = await fetch('/api/overview');
  const d = await r.json();

  document.getElementById('cpu-load').textContent = d.live.cpu_load.toFixed(1) + '%';
  document.getElementById('temp').textContent = (d.live.temp ?? '--') + '°C';
  document.getElementById('ram-pct').textContent = d.live.ram_pct.toFixed(1) + '%';
  document.getElementById('ram-detail').textContent = `${d.live.ram_used_mb} / ${d.live.ram_total_mb} MB`;
  document.getElementById('avg-load').textContent = d.live.avg_load.join(' / ');
  document.getElementById('swap-pct').textContent = d.live.swap_pct.toFixed(1) + '%';
  document.getElementById('swap-detail').textContent = `${d.live.swap_used_mb} / ${d.live.swap_total_mb} MB`;

  document.getElementById('services').innerHTML = d.services.map(s => `
    <div class="service-box">
      ${s.label} <span class="dot ${s.active ? 'on' : 'off'}"></span>
      <button onclick="restartService('${s.unit}')" style="float:right">RESTART</button>
      <div class="sub">${s.mem_mb} MB</div>
    </div>`).join('');

  document.getElementById('hit-rate').textContent = (d.unbound.hit_rate ?? '--') + '%';
  document.getElementById('hit-detail').textContent =
    `${d.unbound.hits ?? '--'} Hits / ${d.unbound.misses ?? '--'} Misses`;
}

let chart;
async function loadSys() {
  const r = await fetch('/api/sys');
  const d = await r.json();

  document.getElementById('uptime').textContent = d.uptime;
  document.getElementById('cpu-freq').textContent = (d.cpu_freq ?? '--') + ' MHz';

  document.getElementById('cores').innerHTML = d.cores.map((c, i) => `
    <div>
      <span class="lbl">CORE ${i}</span>
      <div class="big small">${c.toFixed(1)}%</div>
      <div class="bar"><div class="bar-fill" style="width:${c}%"></div></div>
    </div>`).join('');

  document.getElementById('top-procs').innerHTML = d.top_procs.map(p => `
    <div class="service-box">${p.name}
      <span style="float:right">${(p.cpu_pct ?? 0).toFixed(1)}%</span>
    </div>`).join('');

  document.getElementById('top-mem-procs').innerHTML = d.top_mem_procs.map(p => `
    <div class="service-box">${p.name}
      <span style="float:right">${p.mem_mb ?? 0} MB</span>
    </div>`).join('');

  const labels = d.trends.map(t => t.t);
  const temps = d.trends.map(t => t.temp);
  const cpus = d.trends.map(t => t.cpu);
  const rams = d.trends.map(t => t.ram);

  if (!chart) {
    chart = new Chart(document.getElementById('trend-chart'), {
      type: 'line',
      data: {
        labels,
        datasets: [
          { label: 'Temp (°C)', data: temps, borderColor: '#ff2d6d', tension: 0.3, pointRadius: 0 },
          { label: 'CPU (%)', data: cpus, borderColor: '#22e6e6', tension: 0.3, pointRadius: 0 },
          { label: 'RAM (%)', data: rams, borderColor: '#b84dff', tension: 0.3, pointRadius: 0 },
        ],
      },
      options: {
        scales: { y: { min: 0, max: 100 } },
        animation: false,
        plugins: { legend: { labels: { color: '#d8e0ff' } } },
      },
    });
  } else {
    chart.data.labels = labels;
    chart.data.datasets[0].data = temps;
    chart.data.datasets[1].data = cpus;
    chart.data.datasets[2].data = rams;
    chart.update();
  }
}

async function loadNet() {
  const [r, sr] = await Promise.all([fetch('/api/net'), fetch('/api/proton/servers')]);
  const d = await r.json();
  const sd = await sr.json();

  document.getElementById('net-mode').textContent = d.mode;
  document.getElementById('saved-select').innerHTML =
    d.saved_networks.map(s => `<option>${s}</option>`).join('');
  document.getElementById('available-networks').innerHTML =
    d.available_networks.map(n => `
      <div class="net-item">${n.ssid}
        <span class="sub">${n.security} | ${n.signal}%</span>
      </div>`).join('');

  const p = d.proton;
  let statusHtml;
  if (!p.up) {
    statusHtml = '<span class="dot off"></span> Not running';
  } else if (p.handshake_age_s === null) {
    statusHtml = `<span class="dot off"></span> ${p.active_server} - up, no handshake yet`;
  } else {
    const mins = Math.floor(p.handshake_age_s / 60);
    const fresh = p.handshake_age_s < 300;
    statusHtml = `<span class="dot ${fresh ? 'on' : 'off'}"></span>
      <b>${p.active_server}</b> &middot; last handshake ${mins < 1 ? '&lt;1m' : mins + 'm'} ago &middot;
      ${p.rx_mb} MB in / ${p.tx_mb} MB out`;
  }
  document.getElementById('proton-status').innerHTML = statusHtml;

  const serverListHtml = sd.servers.map(s => {
    const isActive = p.up && p.active_server === s;
    let label;
    if (isActive) label = 'ACTIVE';
    else if (!p.up) label = 'CONNECT';
    else label = 'SWITCH TO';
    return `<div class="net-item">
      ${s.toUpperCase()} ${isActive ? '<span class="dot on"></span>' : ''}
      <button style="float:right" ${isActive ? 'disabled' : ''} onclick="switchProton('${s}')">
        ${label}
      </button>
    </div>`;
  }).join('') || '<div class="sub">No server configs found in /etc/wireguard/</div>';
  document.getElementById('proton-servers').innerHTML = serverListHtml +
    (p.up ? `<div style="margin-top:8px"><button class="danger" onclick="turnOffProton()">DISCONNECT</button></div>` : '');

  document.getElementById('ts-peers').innerHTML = (d.ts_peers || []).map(peer => `
    <div class="net-item">${peer.hostname}
      <span class="dot ${peer.online ? 'on' : 'off'}"></span>
    </div>`).join('') || '<div class="sub">No peers found</div>';

  document.getElementById('net-usage').innerHTML = d.net_ifaces.map(i => `
    <div class="net-item">${i.iface}
      <span class="sub">${i.rx_mb === null ? 'not active' : i.rx_mb + ' MB in / ' + i.tx_mb + ' MB out'}</span>
    </div>`).join('');
}

async function switchProton(server) {
  toast(`Switching to ${server.toUpperCase()}...`);
  try {
    const r = await fetch('/api/action/proton/switch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ server }),
    });
    const d = await r.json();
    toast(d.ok ? `Now on ${server.toUpperCase()}` : 'Switch failed', !d.ok);
  } catch (e) {
    toast('Switch failed', true);
  }
  loadNet();
}

async function turnOffProton() {
  toast('Disconnecting Proton...');
  try {
    const r = await fetch('/api/action/proton/off', { method: 'POST' });
    const d = await r.json();
    toast(d.ok ? 'Disconnected' : 'Failed', !d.ok);
  } catch (e) {
    toast('Failed', true);
  }
  loadNet();
}

async function checkEgress() {
  document.getElementById('egress-result').textContent = 'Checking...';
  try {
    const r = await fetch('/api/net/egress');
    const d = await r.json();
    document.getElementById('egress-result').innerHTML =
      `Direct: <b>${d.direct_ip ?? 'failed'}</b><br>` +
      `Exit-node path (what your phone sees): <b>${d.exit_path_ip ?? 'failed'}</b>`;
  } catch (e) {
    document.getElementById('egress-result').textContent = 'Check failed';
  }
}

async function rebootPi() {
  if (!confirm('Reboot the Pi now? Dashboard will be unreachable for about a minute.')) return;
  toast('Rebooting \u2014 give it about a minute');
  try {
    await fetch('/api/action/reboot', { method: 'POST' });
  } catch (e) {
    // A dropped connection here is expected once the reboot actually happens.
  }
}

async function loadDisk() {
  const r = await fetch('/api/disk');
  const d = await r.json();

  document.getElementById('storage-arrays').innerHTML = d.arrays.map(a => `
    <div class="disk-item">
      <b>${a.path}</b>
      <div class="big small">${a.pct.toFixed(1)}%</div>
      <div class="sub">${a.used_gb} / ${a.total_gb} GB</div>
      <div class="bar"><div class="bar-fill" style="width:${a.pct}%"></div></div>
    </div>`).join('');

  document.getElementById('reclaim').innerHTML = d.reclaim.map(r => `
    <div class="disk-item" style="display:flex;justify-content:space-between;align-items:center;gap:10px">
      <div>
        ${r.name} <span class="sub">(${r.path})</span>
        <div class="sub">Size: ${r.size_mb} MB</div>
      </div>
      <button class="danger" onclick="cleanTarget('${r.name === 'System Logs' ? 'logs' : 'apt'}')">CLEAN</button>
    </div>`).join('');
}

async function restartService(unit) {
  await fetch('/api/action/restart/' + unit, { method: 'POST' });
  loadOverview();
}

async function connectSaved() {
  const ssid = document.getElementById('saved-select').value;
  await fetch('/api/action/wifi/connect_saved', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ssid }),
  });
  loadNet();
}

async function connectNew() {
  const ssid = document.getElementById('new-ssid').value;
  const password = document.getElementById('new-pass').value;
  await fetch('/api/action/wifi/connect_new', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ssid, password }),
  });
  loadNet();
}

async function cleanTarget(target) {
  toast('Cleaning...');
  try {
    const r = await fetch('/api/action/clean/' + target, { method: 'POST' });
    const d = await r.json();
    toast(d.ok ? 'Done \u2014 space reclaimed' : 'Clean failed', !d.ok);
  } catch (e) {
    toast('Clean failed', true);
  }
  loadDisk();
}

async function checkUpdates() {
  document.getElementById('update-status').textContent = 'Checking...';
  try {
    const r = await fetch('/api/updates/check');
    const d = await r.json();
    document.getElementById('update-status').textContent =
      d.upgradable > 0 ? `${d.upgradable} package(s) can be upgraded` : 'System is up to date';
  } catch (e) {
    document.getElementById('update-status').textContent = 'Check failed';
  }
}

let upgradePollTimer = null;
async function runUpgrade() {
  const btn = document.getElementById('upgrade-btn');
  btn.disabled = true;
  toast('Full upgrade started \u2014 this can take a while...');
  try {
    const r = await fetch('/api/updates/upgrade', { method: 'POST' });
    if (r.status === 409) {
      toast('An upgrade is already running', true);
      btn.disabled = false;
      return;
    }
  } catch (e) {
    toast('Could not start upgrade', true);
    btn.disabled = false;
    return;
  }
  pollUpgradeStatus();
}

async function pollUpgradeStatus() {
  clearTimeout(upgradePollTimer);
  const r = await fetch('/api/updates/status');
  const d = await r.json();
  const btn = document.getElementById('upgrade-btn');
  if (d.running) {
    document.getElementById('update-status').textContent = 'Upgrading...';
    btn.disabled = true;
    upgradePollTimer = setTimeout(pollUpgradeStatus, 4000);
  } else {
    btn.disabled = false;
    if (d.done_ok === true) {
      toast('Upgrade complete');
      checkUpdates();
    } else if (d.done_ok === false) {
      toast('Upgrade finished with errors', true);
    }
  }
}

function loadTab(tab) {
  if (tab === 'over') loadOverview();
  if (tab === 'sys') loadSys();
  if (tab === 'net') loadNet();
  if (tab === 'disk') loadDisk();
}

const savedTab = localStorage.getItem('pc_active_tab');
if (savedTab && TAB_ORDER.includes(savedTab)) {
  activateTab(savedTab);
} else {
  loadOverview();
}
checkUpdates();
pollUpgradeStatus();
setInterval(() => {
  const active = document.querySelector('#tabbar button.active').dataset.tab;
  loadTab(active);
}, 5000);
