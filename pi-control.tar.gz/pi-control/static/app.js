const CSRF_TOKEN = document.body.dataset.csrfToken;

// HTML-escapes untrusted text before it goes into a template-literal string
// destined for innerHTML - anything sourced from outside this app's own code
// (WiFi SSIDs, Tailscale peer hostnames, journalctl lines that can embed an
// attempted SSH username, etc.) needs this; our own fixed strings/numbers
// don't.
function esc(s) {
  const d = document.createElement('div');
  d.textContent = String(s ?? '');
  return d.innerHTML;
}

function apiPost(url, body) {
  const headers = { 'X-CSRF-Token': CSRF_TOKEN };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  return fetch(url, {
    method: 'POST',
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
}

function toast(message, isError = false) {
  const el = document.getElementById('toast');
  el.textContent = message;
  el.classList.toggle('error', isError);
  el.classList.add('show');
  clearTimeout(el._hideTimer);
  el._hideTimer = setTimeout(() => el.classList.remove('show'), 3200);
}

const tabButtons = document.querySelectorAll('#nav-drawer button[data-tab]');
const titleEl = document.getElementById('page-title');
const titles = {
  over: 'OVERVIEW', sys: 'SYSTEM DETAILS', net: 'LIVE NETWORK', disk: 'STORAGE ARRAYS',
  term: 'TERMINAL', alerts: 'ALERTS', logs: 'SERVICE LOGS', security: 'SECURITY',
};

const TAB_ORDER = ['over', 'sys', 'net', 'disk', 'term', 'alerts', 'logs', 'security'];
// Only these tabs auto-refresh every 5s while active - logs/security/alerts
// would otherwise reset scroll position or stomp on in-progress threshold
// edits, so those load once per tab switch (or an explicit reload) instead.
const AUTO_POLL_TABS = ['over', 'sys', 'net', 'disk'];

const navDrawer = document.getElementById('nav-drawer');
const navScrim = document.getElementById('nav-scrim');

function openDrawer() {
  navDrawer.classList.add('open');
  navScrim.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeDrawer() {
  navDrawer.classList.remove('open');
  navScrim.classList.remove('open');
  document.body.style.overflow = '';
}

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeDrawer();
});

function activateTab(name) {
  tabButtons.forEach(b => b.classList.toggle('active', b.dataset.tab === name));
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  titleEl.textContent = titles[name];
  localStorage.setItem('pc_active_tab', name);
  loadTab(name);
  closeDrawer();
}

tabButtons.forEach(btn => {
  btn.addEventListener('click', () => activateTab(btn.dataset.tab));
});

// Swipe navigation: swipe left -> next tab, swipe right -> previous tab.
// .tab has touch-action: pan-y (so our own JS handles horizontal gestures
// instead of fighting the browser's native scroll) - which means a swipe
// that fails these checks doesn't fall back to any native behavior either,
// it just does nothing. The original thresholds (70px, and dx needing to
// be 1.5x dy) were strict enough that a normal hand's natural arc during a
// swipe - some vertical drift is unavoidable - regularly failed to
// register, which read as "the dashboard doesn't respond" rather than
// "that wasn't recognized as a swipe". Loosened both, plus added a max
// duration so a slow drag still doesn't get mistaken for one.
let touchStartX = null;
let touchStartY = null;
let touchStartTime = null;
let touchStartTarget = null;

document.body.addEventListener('touchstart', e => {
  touchStartX = e.changedTouches[0].screenX;
  touchStartY = e.changedTouches[0].screenY;
  touchStartTime = Date.now();
  touchStartTarget = e.target;
});

document.body.addEventListener('touchend', e => {
  if (touchStartX === null) return;
  const dx = e.changedTouches[0].screenX - touchStartX;
  const dy = e.changedTouches[0].screenY - touchStartY;
  const dt = Date.now() - touchStartTime;
  touchStartX = null;

  // Ignore swipes while the drawer is open (that's its own interaction
  // surface, not the tab content), that started on a button/input/select,
  // took too long (a slow drag, not a flick), or were more vertical than
  // horizontal (likely a scroll, not a tab-swipe gesture).
  if (navDrawer.classList.contains('open')) return;
  const startedOnControl = touchStartTarget && touchStartTarget.closest('button, input, select');
  if (startedOnControl) return;
  if (dt > 600) return;
  if (Math.abs(dx) < 45 || Math.abs(dx) < Math.abs(dy) * 1.1) return;

  const current = document.querySelector('#nav-drawer button.active').dataset.tab;
  let idx = TAB_ORDER.indexOf(current);
  if (dx < 0) idx = Math.min(idx + 1, TAB_ORDER.length - 1);
  else idx = Math.max(idx - 1, 0);
  activateTab(TAB_ORDER[idx]);
});

async function loadOverview() {
  // The first load skips the round-trip entirely - the server embeds a
  // fresh snapshot straight into the page (see index.html), so Overview
  // paints with real data instantly instead of waiting on a fetch over
  // Tailscale. Every load after this one is a normal fetch.
  let d;
  if (window.__INITIAL_OVERVIEW__) {
    d = window.__INITIAL_OVERVIEW__;
    window.__INITIAL_OVERVIEW__ = null;
  } else {
    const r = await fetch('/api/overview');
    d = await r.json();
  }

  document.getElementById('cpu-load').textContent = d.live.cpu_load.toFixed(1) + '%';
  document.getElementById('temp').textContent = (d.live.temp ?? '--') + '°C';
  document.getElementById('ram-pct').textContent = d.live.ram_pct.toFixed(1) + '%';
  document.getElementById('ram-detail').textContent = `${d.live.ram_used_mb} / ${d.live.ram_total_mb} MB`;
  document.getElementById('avg-load').textContent = d.live.avg_load.join(' / ');
  document.getElementById('swap-pct').textContent = d.live.swap_pct.toFixed(1) + '%';
  document.getElementById('swap-detail').textContent = d.zram && d.zram.ratio
    ? `${d.live.swap_used_mb} / ${d.live.swap_total_mb} MB (${d.zram.ratio}x compressed)`
    : `${d.live.swap_used_mb} / ${d.live.swap_total_mb} MB`;

  document.getElementById('services').innerHTML = d.services.map(s => `
    <div class="service-box">
      ${s.label} <span class="dot ${s.active ? 'on' : 'off'}"></span>
      <button onclick="restartService('${s.unit}')" style="float:right">RESTART</button>
      <div class="sub">${s.mem_mb} MB</div>
    </div>`).join('');

  document.getElementById('hit-rate').textContent = (d.unbound.hit_rate ?? '--') + '%';
  document.getElementById('hit-detail').textContent =
    `${d.unbound.hits ?? '--'} Hits / ${d.unbound.misses ?? '--'} Misses`;

  const pw = d.power || {};
  const activeNow = ['undervoltage_now', 'freq_capped_now', 'throttled_now']
    .filter(k => pw[k]).map(k => k.replace('_now', '').replace('_', ' '));
  const sinceBoot = ['undervoltage_occurred', 'freq_capped_occurred', 'throttled_occurred']
    .filter(k => pw[k]).map(k => k.replace('_occurred', '').replace('_', ' '));
  if (activeNow.length) {
    document.getElementById('power-status').innerHTML = '<span class="dot off"></span> ISSUE';
    document.getElementById('power-detail').textContent = 'Active now: ' + activeNow.join(', ');
  } else if (sinceBoot.length) {
    document.getElementById('power-status').innerHTML = '<span class="dot on"></span> OK';
    document.getElementById('power-detail').textContent = 'Occurred since boot: ' + sinceBoot.join(', ');
  } else {
    document.getElementById('power-status').innerHTML = '<span class="dot on"></span> OK';
    document.getElementById('power-detail').textContent = 'No undervoltage/throttling detected';
  }

  const events = d.system_events || [];
  if (!events.length) {
    document.getElementById('events-status').innerHTML =
      '<span class="dot on"></span> No OOM/throttle/failover events in the last 24h';
    document.getElementById('events-list').innerHTML = '';
  } else {
    document.getElementById('events-status').innerHTML =
      `<span class="dot off"></span> ${events.length} event(s) in the last 24h`;
    document.getElementById('events-list').innerHTML =
      events.map(line => `<div class="service-box">${esc(line)}</div>`).join('');
  }
}

async function testTelegram() {
  toast('Sending test alert...');
  try {
    const r = await apiPost('/api/action/telegram/test');
    const d = await r.json();
    toast(d.ok
      ? 'Sent - check your Telegram chat for the test message'
      : `Failed: ${(d.output || 'no output').slice(0, 200)}`, !d.ok);
  } catch (e) {
    toast('Failed: request error', true);
  }
}

async function unbanIp(jail, ip) {
  toast(`Unbanning ${ip}...`);
  try {
    const r = await apiPost('/api/action/fail2ban/unban', { jail, ip });
    const d = await r.json();
    toast(d.ok ? 'Unbanned' : 'Unban failed', !d.ok);
  } catch (e) {
    toast('Unban failed', true);
  }
  loadSecurity();
}

// Chart.js is only needed on the System tab - load it on first visit
// instead of blocking every page load (it's the single biggest static asset).
let chartLibPromise = null;
function loadChartLib() {
  if (window.Chart) return Promise.resolve();
  if (!chartLibPromise) {
    chartLibPromise = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = '/static/vendor/chart.umd.min.js';
      s.onload = resolve;
      s.onerror = reject;
      document.head.appendChild(s);
    });
  }
  return chartLibPromise;
}

let longChart;
let lastLongTrendsFetch = 0;
async function loadLongTrends() {
  // 5min-resolution data barely changes within a few seconds - only refetch
  // roughly once a minute even though loadSys() itself polls every 5s.
  const now = Date.now();
  if (longChart && now - lastLongTrendsFetch < 60000) return;
  lastLongTrendsFetch = now;

  const r = await fetch('/api/trends/long?days=7');
  const d = await r.json();
  const labels = d.map(t => new Date(t.ts * 1000).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }));
  const temps = d.map(t => t.temp);
  const cpus = d.map(t => t.cpu);
  const rams = d.map(t => t.ram);
  const swaps = d.map(t => t.swap);

  if (!longChart) {
    longChart = new Chart(document.getElementById('trend-chart-long'), {
      type: 'line',
      data: {
        labels,
        datasets: [
          { label: 'Temp (°C)', data: temps, borderColor: '#ff2d6d', tension: 0.3, pointRadius: 0 },
          { label: 'CPU (%)', data: cpus, borderColor: '#22e6e6', tension: 0.3, pointRadius: 0 },
          { label: 'RAM (%)', data: rams, borderColor: '#b84dff', tension: 0.3, pointRadius: 0 },
          { label: 'Swap (%)', data: swaps, borderColor: '#ffaa33', tension: 0.3, pointRadius: 0 },
        ],
      },
      options: {
        scales: { y: { min: 0, max: 100 } },
        animation: false,
        plugins: { legend: { labels: { color: '#d8e0ff' } } },
      },
    });
  } else {
    longChart.data.labels = labels;
    longChart.data.datasets[0].data = temps;
    longChart.data.datasets[1].data = cpus;
    longChart.data.datasets[2].data = rams;
    longChart.data.datasets[3].data = swaps;
    longChart.update();
  }
}

let chart;
async function loadSys() {
  // /api/sys is a plain cache read with no dependency on Chart.js - kick it
  // off immediately instead of waiting on the chart-loading chain below,
  // which can be slow on the very first System-tab visit (204KB fetch).
  const sysPromise = fetch('/api/sys').then(r => r.json());
  await loadChartLib();
  await loadLongTrends();
  const d = await sysPromise;

  document.getElementById('uptime').textContent = d.uptime;
  document.getElementById('cpu-freq').textContent = (d.cpu_freq ?? '--') + ' MHz';

  document.getElementById('cores').innerHTML = d.cores.map((c, i) => `
    <div>
      <span class="lbl">CORE ${i}</span>
      <div class="big small">${c.toFixed(1)}%</div>
      <div class="bar"><div class="bar-fill" style="width:${c}%"></div></div>
    </div>`).join('');

  document.getElementById('top-procs').innerHTML = d.top_procs.map(p => `
    <div class="service-box">${p.name}
      <span style="float:right">${(p.cpu_pct ?? 0).toFixed(1)}%</span>
    </div>`).join('');

  document.getElementById('top-mem-procs').innerHTML = d.top_mem_procs.map(p => `
    <div class="service-box">${p.name}
      <span style="float:right">${p.mem_mb ?? 0} MB</span>
    </div>`).join('');

  const labels = d.trends.map(t => t.t);
  const temps = d.trends.map(t => t.temp);
  const cpus = d.trends.map(t => t.cpu);
  const rams = d.trends.map(t => t.ram);

  if (!chart) {
    chart = new Chart(document.getElementById('trend-chart'), {
      type: 'line',
      data: {
        labels,
        datasets: [
          { label: 'Temp (°C)', data: temps, borderColor: '#ff2d6d', tension: 0.3, pointRadius: 0 },
          { label: 'CPU (%)', data: cpus, borderColor: '#22e6e6', tension: 0.3, pointRadius: 0 },
          { label: 'RAM (%)', data: rams, borderColor: '#b84dff', tension: 0.3, pointRadius: 0 },
        ],
      },
      options: {
        scales: { y: { min: 0, max: 100 } },
        animation: false,
        plugins: { legend: { labels: { color: '#d8e0ff' } } },
      },
    });
  } else {
    chart.data.labels = labels;
    chart.data.datasets[0].data = temps;
    chart.data.datasets[1].data = cpus;
    chart.data.datasets[2].data = rams;
    chart.update();
  }

  const ub = d.unbound || {};
  document.getElementById('ub-total-queries').textContent = ub.total_queries ?? '--';
  document.getElementById('ub-hit-rate').textContent = (ub.hit_rate ?? '--') + '%';
  document.getElementById('ub-prefetch').textContent = ub.prefetch ?? '--';
  document.getElementById('ub-expired').textContent = ub.expired ?? '--';
  document.getElementById('ub-recursive-replies').textContent = ub.recursive_replies ?? '--';
  document.getElementById('ub-uptime').textContent = ub.uptime ?? '--';
  document.getElementById('ub-recursion-avg').textContent = (ub.recursion_avg_ms ?? '--') + ' ms';
  document.getElementById('ub-recursion-median').textContent = (ub.recursion_median_ms ?? '--') + ' ms';
  document.getElementById('ub-reqlist-avg').textContent = ub.requestlist_avg ?? '--';
  document.getElementById('ub-reqlist-max').textContent = ub.requestlist_max ?? '--';
  document.getElementById('ub-ratelimited').textContent = ub.ratelimited ?? '--';
  document.getElementById('ub-timedout').textContent = ub.timed_out ?? '--';

  loadUnboundTrends();
}

let unboundChart;
let lastUnboundTrendsFetch = 0;
async function loadUnboundTrends() {
  // Same "don't refetch every 5s" throttling as loadLongTrends() - this is
  // a 5min-resolution series, no reason to hit it on every SYS-tab poll.
  const now = Date.now();
  if (unboundChart && now - lastUnboundTrendsFetch < 60000) return;
  lastUnboundTrendsFetch = now;

  const r = await fetch('/api/unbound/trends?hours=6');
  const d = await r.json();
  const labels = d.map(t => new Date(t.ts * 1000).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' }));
  const avgs = d.map(t => t.recursion_avg_ms);
  const medians = d.map(t => t.recursion_median_ms);

  if (!unboundChart) {
    unboundChart = new Chart(document.getElementById('unbound-trend-chart'), {
      type: 'line',
      data: {
        labels,
        datasets: [
          { label: 'Avg (ms)', data: avgs, borderColor: '#22e6e6', tension: 0.3, pointRadius: 0 },
          { label: 'Median (ms)', data: medians, borderColor: '#ffaa33', tension: 0.3, pointRadius: 0 },
        ],
      },
      options: {
        scales: { y: { min: 0 } },
        animation: false,
        plugins: { legend: { labels: { color: '#d8e0ff' } } },
      },
    });
  } else {
    unboundChart.data.labels = labels;
    unboundChart.data.datasets[0].data = avgs;
    unboundChart.data.datasets[1].data = medians;
    unboundChart.update();
  }
}

async function loadStaticApps() {
  const r = await fetch('/api/sites/status');
  const d = await r.json();
  document.getElementById('static-apps').innerHTML = d.sites.map(s => `
    <div class="net-item">${esc(s.label)}
      <span class="dot ${s.enabled ? 'on' : 'off'}"></span>
      <div class="sub">
        ${s.enabled ? `<a href="https://${esc(location.hostname)}:${s.port}/" target="_blank" rel="noopener">Open &rarr;</a>` : 'Disabled'}
      </div>
      <div style="margin-top:6px">
        <button onclick="toggleSite('${s.name}', ${!s.enabled})">${s.enabled ? 'DISABLE' : 'ENABLE'}</button>
      </div>
    </div>`).join('') || '<div class="sub">No self-hosted apps configured</div>';
}

async function toggleSite(name, enable) {
  toast(enable ? 'Enabling...' : 'Disabling...');
  try {
    const r = await apiPost(`/api/action/sites/${name}/${enable ? 'enable' : 'disable'}`);
    const d = await r.json();
    toast(d.ok ? (enable ? 'Enabled' : 'Disabled') : `Failed: ${d.error || d.output || 'unknown error'}`, !d.ok);
  } catch (e) {
    toast('Request failed', true);
  }
  loadStaticApps();
}

async function loadNet() {
  loadStaticApps();
  const [r, sr] = await Promise.all([fetch('/api/net'), fetch('/api/proton/servers')]);
  const d = await r.json();
  const sd = await sr.json();

  document.getElementById('net-mode').textContent = d.mode;

  const savedSelect = document.getElementById('saved-select');
  savedSelect.innerHTML = '';
  d.saved_networks.forEach(s => {
    const opt = document.createElement('option');
    opt.textContent = s;
    savedSelect.appendChild(opt);
  });

  // SSID/security come straight from a WiFi scan - any nearby device can
  // broadcast an arbitrary SSID, so this is attacker-controlled data and
  // must never go through innerHTML. textContent escapes it automatically.
  const availableEl = document.getElementById('available-networks');
  availableEl.innerHTML = '';
  d.available_networks.forEach(n => {
    const item = document.createElement('div');
    item.className = 'net-item';
    item.appendChild(document.createTextNode(n.ssid));
    const sub = document.createElement('span');
    sub.className = 'sub';
    sub.textContent = `${n.security} | ${n.signal}%`;
    item.appendChild(sub);
    availableEl.appendChild(item);
  });

  const p = d.proton;

  // If this Pi is offering itself as a Tailscale exit node while Proton is
  // off, peer traffic goes direct instead of through the geo-exit - easy to
  // not notice since the two statuses live in unrelated systems.
  const killswitchOn = d.ts_self_offers_exit && !p.up;
  const killswitchEl = document.getElementById('killswitch-warning');
  killswitchEl.classList.toggle('show', killswitchOn);
  killswitchEl.textContent = killswitchOn
    ? 'WARNING: exit node active, Proton is OFF — peer traffic is going direct, not through Proton'
    : '';

  let statusHtml;
  if (!p.up) {
    statusHtml = '<span class="dot off"></span> Not running';
  } else if (p.handshake_age_s === null) {
    statusHtml = `<span class="dot off"></span> ${p.active_server} - up, no handshake yet`;
  } else {
    const mins = Math.floor(p.handshake_age_s / 60);
    const fresh = p.handshake_age_s < 300;
    statusHtml = `<span class="dot ${fresh ? 'on' : 'off'}"></span>
      <b>${p.active_server}</b> &middot; last handshake ${mins < 1 ? '&lt;1m' : mins + 'm'} ago &middot;
      ${p.rx_mb} MB in / ${p.tx_mb} MB out`;
  }
  document.getElementById('proton-status').innerHTML = statusHtml;

  const serverListHtml = sd.servers.map(s => {
    const isActive = p.up && p.active_server === s;
    let label;
    if (isActive) label = 'ACTIVE';
    else if (!p.up) label = 'CONNECT';
    else label = 'SWITCH TO';
    return `<div class="net-item">
      ${s.toUpperCase()} ${isActive ? '<span class="dot on"></span>' : ''}
      <button style="float:right" ${isActive ? 'disabled' : ''} onclick="switchProton('${s}')">
        ${label}
      </button>
    </div>`;
  }).join('') || '<div class="sub">No server configs found in /etc/wireguard/</div>';
  document.getElementById('proton-servers').innerHTML = serverListHtml +
    (p.up ? `<div style="margin-top:8px"><button class="danger" onclick="turnOffProton()">DISCONNECT</button></div>` : '');

  document.getElementById('ts-peers').innerHTML = (d.ts_peers || []).map(peer => `
    <div class="net-item">${esc(peer.hostname)}
      <span class="dot ${peer.online ? 'on' : 'off'}"></span>
      <div class="sub">${esc(peer.ip ?? 'no IP')}</div>
    </div>`).join('') || '<div class="sub">No peers found</div>';

  document.getElementById('net-usage').innerHTML = d.net_ifaces.map(i => `
    <div class="net-item">${i.iface}
      <span class="sub">${i.rx_mb === null ? 'not active' : i.rx_mb + ' MB in / ' + i.tx_mb + ' MB out'}</span>
    </div>`).join('');
}

async function switchProton(server) {
  toast(`Switching to ${server.toUpperCase()}...`);
  try {
    const r = await apiPost('/api/action/proton/switch', { server });
    const d = await r.json();
    toast(d.ok ? `Now on ${server.toUpperCase()}` : 'Switch failed', !d.ok);
  } catch (e) {
    toast('Switch failed', true);
  }
  loadNet();
}

async function turnOffProton() {
  toast('Disconnecting Proton...');
  try {
    const r = await apiPost('/api/action/proton/off');
    const d = await r.json();
    toast(d.ok ? 'Disconnected' : 'Failed', !d.ok);
  } catch (e) {
    toast('Failed', true);
  }
  loadNet();
}

async function checkEgress() {
  document.getElementById('egress-result').textContent = 'Checking...';
  try {
    const r = await fetch('/api/net/egress');
    const d = await r.json();
    // IP + geolocation both come from external services (ifconfig.me, the
    // sudo helper, ipinfo.io) - esc() before touching innerHTML, same
    // reasoning as the WiFi SSID fix.
    //
    // `ok` distinguishes a real IP from the sudo helper's own diagnostic
    // text (e.g. "curl_failed_via_tailscale0") when the exit-node path
    // itself is down - that text isn't an IP, so show it as an error
    // instead of pretending it's a value (and never bother geolocating it,
    // handled server-side already).
    const fmt = (ip, geo, ok) => {
      if (!ip) return 'failed';
      if (!ok) return `<span style="color:var(--pink)">${esc(ip)}</span>`;
      let s = esc(ip);
      if (geo && geo.label) {
        s += ` <span class="sub">(${esc(geo.label)}${geo.org ? ' &middot; ' + esc(geo.org) : ''})</span>`;
      }
      return s;
    };
    document.getElementById('egress-result').innerHTML =
      `Direct: <b>${fmt(d.direct_ip, d.direct_geo, d.direct_ok)}</b><br>` +
      `Exit-node path (what your phone sees): <b>${fmt(d.exit_path_ip, d.exit_geo, d.exit_ok)}</b>`;
  } catch (e) {
    document.getElementById('egress-result').textContent = 'Check failed';
  }
}

// Deliberately NOT hooked into loadTab()/AUTO_POLL_TABS - the 'over' tab
// auto-polls every 5s and weather doesn't need (or deserve, against a free
// no-key API) that cadence. Loaded once at startup and on its own slow
// interval below instead.
// The Pi itself never moves, so weather for wherever it's plugged in isn't
// what you actually want - try the browser's own geolocation first (this
// is the phone/laptop looking at the dashboard right now, not the Pi), and
// only fall back to the saved default location if that's unavailable,
// denied, or times out. Needs a real HTTPS origin to work at all (browsers
// block the Geolocation API outright on an insecure one) - the Tailscale
// cert from Phase 10 is what makes this possible.
function _browserLocation() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) { reject(new Error('unsupported')); return; }
    navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy: false,
      timeout: 6000,
      maximumAge: 10 * 60 * 1000, // a position up to 10min old is plenty fresh for weather
    });
  });
}

async function loadWeather() {
  let query = '';
  try {
    const pos = await _browserLocation();
    query = `?lat=${pos.coords.latitude}&lon=${pos.coords.longitude}`;
  } catch (e) {
    // Permission denied / unsupported browser / timed out - /api/weather
    // falls back to the saved default location on its own when no lat/lon
    // is passed, so just proceed without one.
  }

  try {
    const r = await fetch('/api/weather' + query);
    const d = await r.json();
    if (!d.ok) {
      document.getElementById('weather-display').style.display = 'none';
      document.getElementById('weather-setup').style.display = 'block';
      return;
    }
    document.getElementById('weather-condition').textContent = d.condition;
    document.getElementById('weather-temp').textContent = (d.temp_c ?? '--') + '°C';
    document.getElementById('weather-humidity').textContent = (d.humidity_pct ?? '--') + '%';
    document.getElementById('weather-wind').textContent = (d.wind_kmh ?? '--') + ' km/h';
    document.getElementById('weather-source').textContent =
      d.source === 'live' ? 'Your current location' : 'Saved location';
    document.getElementById('weather-display').style.display = 'block';
    document.getElementById('weather-setup').style.display = 'none';
  } catch (e) {
    // Leave whatever was last shown rather than blank it on a transient failure.
  }
}

function toggleWeatherSetup() {
  const el = document.getElementById('weather-setup');
  el.style.display = el.style.display === 'none' ? 'block' : 'none';
}

async function detectWeatherLocation() {
  toast('Detecting location from this Pi\'s IP...');
  try {
    const r = await apiPost('/api/weather/detect-location');
    const d = await r.json();
    if (d.ok) {
      document.getElementById('weather-lat').value = d.lat;
      document.getElementById('weather-lon').value = d.lon;
      toast(`Detected: ${d.label || 'unknown location'} — check it looks right, then SAVE`);
    } else {
      toast(`Failed: ${d.error || 'unknown error'}`, true);
    }
  } catch (e) {
    toast('Request failed', true);
  }
}

async function saveWeatherLocation() {
  const lat = parseFloat(document.getElementById('weather-lat').value);
  const lon = parseFloat(document.getElementById('weather-lon').value);
  if (isNaN(lat) || isNaN(lon)) {
    toast('Enter a valid latitude and longitude', true);
    return;
  }
  try {
    const r = await apiPost('/api/weather/location', { lat, lon });
    const d = await r.json();
    if (d.ok) {
      toast('Location saved');
      loadWeather();
    } else {
      toast(`Failed: ${d.error || 'unknown error'}`, true);
    }
  } catch (e) {
    toast('Request failed', true);
  }
}

async function rebootPi() {
  if (!confirm('Reboot the Pi now? Dashboard will be unreachable for about a minute.')) return;
  toast('Rebooting \u2014 give it about a minute');
  try {
    await apiPost('/api/action/reboot');
  } catch (e) {
    // A dropped connection here is expected once the reboot actually happens.
  }
}

async function loadDisk() {
  const r = await fetch('/api/disk');
  const d = await r.json();

  document.getElementById('storage-arrays').innerHTML = d.arrays.map(a => `
    <div class="disk-item">
      <b>${a.path}</b>
      <div class="big small">${a.pct.toFixed(1)}%</div>
      <div class="sub">${a.used_gb} / ${a.total_gb} GB</div>
      <div class="bar"><div class="bar-fill" style="width:${a.pct}%"></div></div>
    </div>`).join('');

  document.getElementById('reclaim').innerHTML = d.reclaim.map(r => `
    <div class="disk-item" style="display:flex;justify-content:space-between;align-items:center;gap:10px">
      <div>
        ${r.name} <span class="sub">(${r.path})</span>
        <div class="sub">Size: ${r.size_mb} MB</div>
      </div>
      <button class="danger" onclick="cleanTarget('${r.name === 'System Logs' ? 'logs' : 'apt'}')">CLEAN</button>
    </div>`).join('');
}

let thresholdsLoadedOnce = false;
async function loadAlerts() {
  // Thresholds are only populated once per tab visit, never on a later
  // poll - this tab isn't in AUTO_POLL_TABS so that's moot for now, but
  // guarding here too means a future change can't accidentally stomp
  // in-progress edits.
  if (!thresholdsLoadedOnce) {
    const tr = await fetch('/api/alerts/thresholds');
    const t = await tr.json();
    document.getElementById('th-temp').value = t.temp_c;
    document.getElementById('th-disk').value = t.disk_pct;
    document.getElementById('th-stale').value = t.stale_handshake_s;
    thresholdsLoadedOnce = true;
  }
  await loadAlertHistory();
}

async function loadAlertHistory() {
  const hr = await fetch('/api/alerts/history?limit=100');
  const history = await hr.json();
  document.getElementById('alert-history').innerHTML = history.length
    ? history.map(a => {
        const dt = new Date(a.ts * 1000).toLocaleString();
        return `<div class="service-box">${esc(a.message).replace(/\n/g, '<br>')}<div class="sub">${esc(dt)}</div></div>`;
      }).join('')
    : '<div class="sub">No alerts recorded yet</div>';
}

async function saveThresholds() {
  const body = {
    temp_c: document.getElementById('th-temp').value,
    disk_pct: document.getElementById('th-disk').value,
    stale_handshake_s: document.getElementById('th-stale').value,
  };
  toast('Saving...');
  try {
    const r = await apiPost('/api/action/alerts/thresholds', body);
    const d = await r.json();
    toast(d.ok ? 'Saved — takes effect on the next poll' : `Failed: ${d.error || 'unknown error'}`, !d.ok);
  } catch (e) {
    toast('Failed: request error', true);
  }
}

async function loadLogs() {
  const unit = document.getElementById('logs-unit').value;
  const lines = document.getElementById('logs-lines').value;
  const box = document.getElementById('logs-output');
  box.textContent = 'Loading...';
  try {
    const r = await fetch(`/api/logs?unit=${encodeURIComponent(unit)}&lines=${encodeURIComponent(lines)}`);
    const d = await r.json();
    box.textContent = d.lines && d.lines.length ? d.lines.join('\n') : 'No log output.';
  } catch (e) {
    box.textContent = 'Failed to load logs.';
  }
}

async function loadSecurity() {
  const r = await fetch('/api/security');
  const d = await r.json();

  document.getElementById('security-fail2ban').innerHTML = d.fail2ban_summary.length
    ? d.fail2ban_summary.map(j => `
      <div class="service-box">${j.jail}
        <span style="float:right">${j.currently_banned} banned now</span>
        <div class="sub">Total failed: ${j.total_failed} &middot; Total banned: ${j.total_banned} &middot; Currently failed: ${j.currently_failed}</div>
      </div>`).join('')
    : '<div class="sub">No fail2ban jails found</div>';

  const banned = d.fail2ban_banned || [];
  document.getElementById('security-fail2ban-banned').innerHTML = banned.length
    ? banned.map(b => `
      <div class="service-box">${b.ip}
        <button class="danger" style="float:right" onclick="unbanIp('${b.jail}','${b.ip}')">UNBAN</button>
        <div class="sub">jail: ${b.jail}</div>
      </div>`).join('')
    : '<div class="sub">No banned IPs</div>';

  document.getElementById('security-ufw').textContent =
    d.ufw_rules.length ? d.ufw_rules.join('\n') : 'No UFW rules found.';

  document.getElementById('security-ssh').innerHTML = d.ssh_auth_log.length
    ? d.ssh_auth_log.map(line => `<div class="service-box">${esc(line)}</div>`).join('')
    : '<div class="sub">No SSH auth activity in the last 24h</div>';
}

// These two have config files that have broken restarts before (Phase 7a) -
// validate before restarting instead of relying on remembering to check first.
const VALIDATABLE_SERVICES = ['AdGuardHome', 'unbound'];

async function restartService(unit) {
  if (VALIDATABLE_SERVICES.includes(unit)) {
    toast(`Validating ${unit} config...`);
    try {
      const vr = await apiPost('/api/action/validate/' + unit);
      const vd = await vr.json();
      if (!vd.ok) {
        toast(`Config invalid, restart blocked: ${(vd.output || '').slice(0, 200)}`, true);
        return;
      }
    } catch (e) {
      toast('Validation check failed, restart blocked', true);
      return;
    }
  }
  await apiPost('/api/action/restart/' + unit);
  loadOverview();
}

async function connectSaved() {
  const ssid = document.getElementById('saved-select').value;
  await apiPost('/api/action/wifi/connect_saved', { ssid });
  loadNet();
}

async function connectNew() {
  const ssid = document.getElementById('new-ssid').value;
  const password = document.getElementById('new-pass').value;
  await apiPost('/api/action/wifi/connect_new', { ssid, password });
  loadNet();
}

async function cleanTarget(target) {
  toast('Cleaning...');
  try {
    const r = await apiPost('/api/action/clean/' + target);
    const d = await r.json();
    toast(d.ok ? 'Done \u2014 space reclaimed' : 'Clean failed', !d.ok);
  } catch (e) {
    toast('Clean failed', true);
  }
  loadDisk();
}

async function checkUpdates() {
  // Reads the cache the background thread keeps warm - instant, no apt-get call.
  try {
    const r = await fetch('/api/updates/check');
    const d = await r.json();
    document.getElementById('update-status').textContent =
      d.upgradable > 0 ? `${d.upgradable} package(s) can be upgraded` : 'System is up to date';
  } catch (e) {
    document.getElementById('update-status').textContent = 'Check failed';
  }
}

async function recheckUpdates() {
  // Explicit user click - fine to actually hit apt-get update live.
  document.getElementById('update-status').textContent = 'Checking...';
  try {
    const r = await apiPost('/api/updates/recheck');
    const d = await r.json();
    document.getElementById('update-status').textContent =
      d.upgradable > 0 ? `${d.upgradable} package(s) can be upgraded` : 'System is up to date';
  } catch (e) {
    document.getElementById('update-status').textContent = 'Check failed';
  }
}

let upgradePollTimer = null;
function upgradeButtons() {
  return [document.getElementById('update-btn'), document.getElementById('full-upgrade-btn')];
}

async function runUpgrade(kind) {
  if (kind === 'full' && !confirm(
    'Run a FULL upgrade now? This can remove/replace packages to satisfy ' +
    'dependency changes and runs autoremove afterward - same as REBOOT, ' +
    'confirm before a system-level change.'
  )) return;
  const btns = upgradeButtons();
  btns.forEach(b => b.disabled = true);
  toast(kind === 'full'
    ? 'Full upgrade started \u2014 this can take a while...'
    : 'Update started...');
  try {
    const r = await apiPost('/api/updates/upgrade', { kind });
    if (r.status === 409) {
      toast('An upgrade is already running', true);
      btns.forEach(b => b.disabled = false);
      return;
    }
    if (!r.ok) {
      // Anything other than 200/409 (a stale CSRF token after a service
      // restart, a bad request, a server error) used to fall through
      // silently into pollUpgradeStatus(), which would just see nothing
      // running and quietly re-enable the buttons with zero feedback -
      // surface the real failure instead.
      let detail = `HTTP ${r.status}`;
      try {
        const d = await r.json();
        if (d && d.error) detail = d.error;
      } catch (e) { /* body wasn't JSON - keep the HTTP status */ }
      toast(`Could not start upgrade: ${detail}`, true);
      btns.forEach(b => b.disabled = false);
      return;
    }
  } catch (e) {
    toast('Could not start upgrade', true);
    btns.forEach(b => b.disabled = false);
    return;
  }
  pollUpgradeStatus();
}

// UPDATE_STATE["done_ok"] on the server stays set to true/false forever
// after an upgrade finishes, until the *next* upgrade run resets it - it's
// a "what happened last time" flag, not a one-shot event. pollUpgradeStatus
// runs unconditionally on every page load (below) to resume showing
// "Updating..." if one is genuinely still in flight, but that same call
// used to also replay the completion toast for a long-finished upgrade on
// every single reload, since done_ok was still sitting there true. Only
// toast when we've actually observed this poll chain transition out of a
// running state, not on first discovering an already-settled result.
let sawUpgradeRunning = false;

async function pollUpgradeStatus() {
  clearTimeout(upgradePollTimer);
  const r = await fetch('/api/updates/status');
  const d = await r.json();
  const btns = upgradeButtons();
  if (d.running) {
    sawUpgradeRunning = true;
    document.getElementById('update-status').textContent = d.kind === 'full' ? 'Full upgrading...' : 'Updating...';
    btns.forEach(b => b.disabled = true);
    upgradePollTimer = setTimeout(pollUpgradeStatus, 4000);
  } else {
    btns.forEach(b => b.disabled = false);
    if (sawUpgradeRunning) {
      sawUpgradeRunning = false;
      if (d.done_ok === true) {
        toast('Upgrade complete');
        // A live recheck, not the 30-min-stale cache checkUpdates() reads -
        // right after an upgrade finishes is exactly when that cache is
        // guaranteed to be wrong, which was the second half of this bug:
        // the dashboard kept showing the pre-upgrade "N packages available"
        // count for up to 30 minutes after the upgrade had already applied
        // them.
        recheckUpdates();
      } else if (d.done_ok === false) {
        toast('Upgrade finished with errors', true);
      }
    }
  }
}

function loadTab(tab) {
  if (tab === 'over') loadOverview();
  if (tab === 'sys') loadSys();
  if (tab === 'net') loadNet();
  if (tab === 'disk') loadDisk();
  if (tab === 'alerts') loadAlerts();
  if (tab === 'logs') loadLogs();
  if (tab === 'security') loadSecurity();
}

const savedTab = localStorage.getItem('pc_active_tab');
if (savedTab && TAB_ORDER.includes(savedTab)) {
  activateTab(savedTab);
} else {
  loadOverview();
}
checkUpdates();
pollUpgradeStatus();
loadWeather();
setInterval(() => {
  const active = document.querySelector('#nav-drawer button.active').dataset.tab;
  if (AUTO_POLL_TABS.includes(active)) loadTab(active);
}, 5000);
setInterval(loadWeather, 15 * 60 * 1000);
