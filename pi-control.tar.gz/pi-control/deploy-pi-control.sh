#!/bin/bash
# deploy-pi-control.sh - runs the full pi-control deploy sequence in order.
#
# Lives inside the tarball at pi-control/deploy-pi-control.sh. After the
# very first extraction, just re-run this same path every time a new
# pi-control.tar.gz lands in $HOME - it re-extracts, copies everything
# into place, and restarts the service itself.
#
# Usage: bash ~/pi-control/deploy-pi-control.sh
# (assumes ~/pi-control.tar.gz or ~/pi-control.tar is already there,
# downloaded from Android via Termux same as always)
set -euo pipefail

cd "$HOME"

echo "==> Stopping picontrol"
sudo systemctl stop picontrol

echo "==> Extracting pi-control archive"
tar xzf "$HOME/pi-control.tar.gz" -C "$HOME" 2>/dev/null || tar xf "$HOME/pi-control.tar" -C "$HOME"

echo "==> Copying app files to /opt/pi-control"
sudo cp -r "$HOME/pi-control/"* /opt/pi-control/

echo "==> Installing pi-control-helper.sh"
sudo cp /opt/pi-control/pi-control-helper.sh /usr/local/bin/
sudo chmod 755 /usr/local/bin/pi-control-helper.sh

echo "==> Installing telegram-send.sh"
sudo cp /opt/pi-control/telegram-send.sh /usr/local/bin/
sudo chmod 755 /usr/local/bin/telegram-send.sh

echo "==> Starting picontrol"
sudo systemctl start picontrol

echo "==> Done. Status:"
sudo systemctl status picontrol --no-pager -l | head -10
