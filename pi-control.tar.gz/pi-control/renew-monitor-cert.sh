#!/bin/bash
# renew-monitor-cert.sh - keeps /etc/nginx/ssl/monitor.{crt,key} (the one
# shared TLS cert every nginx site on this Pi uses - pi-control, BentoPDF,
# OmniTools, etc., per Phase 10) renewed via `tailscale cert` before it
# expires. Let's Encrypt certs from `tailscale cert` last ~90 days and
# don't renew themselves - this is what does that.
#
# `tailscale cert` is safe to run repeatedly - it only actually reissues
# when the current cert is nearing expiry, otherwise it just re-writes the
# same bytes - so this can run on a schedule far more often than renewal
# is actually needed and do nothing most weeks.
#
# Deploys to /usr/local/bin/renew-monitor-cert.sh, run by
# /etc/cron.d/pi-control-cert-renew as root - needs root both for
# `tailscale cert` itself (regular users get "access denied", confirmed
# during the Phase 10 manual setup) and to write into the root-owned
# /etc/nginx/ssl/.
set -euo pipefail

DOMAIN="anon.tail8dd783.ts.net"
CERT_DIR="/etc/nginx/ssl"
TAG="pi-control-cert-renew"

TMP_CRT="$(mktemp)"
TMP_KEY="$(mktemp)"
trap 'rm -f "$TMP_CRT" "$TMP_KEY"' EXIT

alert() {
  logger -t "$TAG" "$1"
  # Best-effort - a Telegram outage shouldn't make this script itself fail
  # and get treated as a renewal failure.
  /usr/local/bin/telegram-send.sh "[pi-control] cert renewal: $1" || true
}

if ! OUTPUT=$(tailscale cert --cert-file "$TMP_CRT" --key-file "$TMP_KEY" "$DOMAIN" 2>&1); then
  alert "tailscale cert failed - $OUTPUT"
  exit 1
fi

if cmp -s "$TMP_CRT" "$CERT_DIR/monitor.crt" 2>/dev/null; then
  logger -t "$TAG" "cert unchanged, nothing to do"
  exit 0
fi

install -o root -g root -m 644 "$TMP_CRT" "$CERT_DIR/monitor.crt"
install -o root -g root -m 600 "$TMP_KEY" "$CERT_DIR/monitor.key"

if ! NGINX_TEST=$(nginx -t 2>&1); then
  alert "new cert installed but nginx -t failed - NOT reloaded, investigate: $NGINX_TEST"
  exit 1
fi

systemctl reload nginx
logger -t "$TAG" "cert renewed and nginx reloaded"
